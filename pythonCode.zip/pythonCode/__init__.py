"""Welcome to the documentation of the python code from the FluxNN project
This Documentation containts two main parts
1. **Datapipeline:**
    all the information you need to efficiently use the datapipeline and extend it to your needs
2. **steps:**
    here all the necessary functions for training and evaluation of the neuronal networks are stored."""