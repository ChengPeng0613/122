import pandas as pd
import joblib
import torch
import os
import logging

class FileWriter:
    """Class for writing various types of files. Currently '.csv', '.pkl' and '.pt' are supported"""
    
    def __init__(self):
        """
        Initializes the FileWriter with supported file types and their corresponding writing methods.
        """
        self.writers = {
            ".csv": self._write_csv,
            ".pkl": self._write_pkl,
            ".pt": self._write_pt
        }
        
    def write(self, filepath: str, data) -> None:
        """
        Write data to a file.

        Args:
            filepath (str): The path to the file where data should be written.
            data: The data to be written.

        Raises:
            ValueError: If the file type is unsupported.
        """
        dir, _ = os.path.split(filepath)
        self.create_dir_if_not_existent(dir)
        
        _, file_type = os.path.splitext(filepath)
        if file_type not in self.writers:
            raise ValueError(f"Unsupported file type: {file_type}")
        self.writers[file_type](filepath, data)
            
    def _write_csv(self, filepath: str, data: pd.DataFrame) -> None:
        """
        Write a dataframe to a CSV file.

        Args:
            filepath (str): The path to the CSV file.
            data (pd.DataFrame): The dataframe to be written.
        """
        data.to_csv(filepath)
        
    def _write_pkl(self, filepath: str, data) -> None:
        """
        Write data to a PKL file.

        Args:
            filepath (str): The path to the PKL file.
            data: The data to be written.
        """
        joblib.dump(data, filepath)
    
    def _write_pt(self, filepath: str, data) -> None:
        """
        Write data to a PT file.

        Args:
            filepath (str): The path to the PT file.
            data: The data to be written.
        """
        torch.save(data, filepath)
        
    def create_dir_if_not_existent(self, path: str) -> None:
        """
        Create a directory if it does not exist.

        Args:
            path (str): The path to the directory.
        """
        if not os.path.exists(path):
            os.makedirs(path)
            logging.info(f"Folder '{path}' created.")
        else:
            logging.info(f"Folder '{path}' already exists.")