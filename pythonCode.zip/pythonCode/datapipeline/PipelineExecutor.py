from pythonCode.datapipeline.DataLoader import DataLoader
from pythonCode.datapipeline.FileWriter import FileWriter
import pandas as pd
import os
from typing import Dict, List, Any
from pythonCode.datapipeline.Pipeline import Pipeline
import logging

class PipelineExecutor:
    """Class for executing multiple pipelines in a predefined order."""
    
    def __init__(self, pipelines: Dict[str, Pipeline], filewriter: FileWriter, dataloader: DataLoader, pipeline_data_mapping: Dict[str, str]):
        """
        Initializes the PipelineExecutor with pipelines, file writer, data loader, and data mapping.

        Args:
            pipelines (Dict[str, Pipeline]): A dictionary of pipeline names and their corresponding Pipeline objects.
            filewriter (FileWriter): The file writer to use for outputting data.
            dataloader (DataLoader): The data loader to use for loading data.
            pipeline_data_mapping (Dict[str, str]): A dictionary mapping pipeline names to data keys.
        """
        self.pipelines = pipelines
        self.filewriter = filewriter
        self.dataloader = dataloader
        self.pipeline_data_mapping = pipeline_data_mapping
        
    def run(self, source: str, destination: str, component_args: Dict[str, Dict[str, Dict[str, Any]]]):
        """
        Run all pipelines in the predefined order with the given arguments.

        Args:
            source (str): The source path for loading data.
            destination (str): The destination path for saving results.
            component_args (Dict[str, Dict[str, Dict[str, Any]]]): A dictionary of arguments for each component in each pipeline.

        Raises:
            ValueError: If no valid data key is found for a pipeline.
        """
        self.data = self.dataloader.execute(source)
        
        for name, pipeline in self.pipelines.items():
            logging.info(f"Running pipeline: '{name}'")
            data_key = self.pipeline_data_mapping.get(name)
            if data_key is None or data_key not in self.data.keys():
                raise ValueError(f"No valid data key found for pipeline '{name}'")
            pipeline.run(self.data[data_key], component_args[name],destination=destination)
            
        self.save_artifacts(destination)
        self.save_metadata(destination)
            
    def save_metadata(self, destination: str) -> None:
        """
        Save metadata from all pipelines to the specified destination.

        Args:
            destination (str): The destination path for saving metadata.
        """
        metadata = [p.get_metadata() for p in self.pipelines.values()]
        if "metadata" in self.data.keys():
            metadata.append(self.data["metadata"])
        metadata = pd.concat(metadata, axis=1)
        self.filewriter.write(os.path.join(destination, "metadata.csv"), metadata)
        
    def save_artifacts(self, destination: str) -> None:
        """
        Save artifacts from all pipelines to the specified destination.

        Args:
            destination (str): The destination path for saving artifacts.
        """
        for pipeline in self.pipelines.values():
            for key, artifact in pipeline.get_artifacts().items():
                self.filewriter.write(os.path.join(destination, key + ".pkl"), artifact)