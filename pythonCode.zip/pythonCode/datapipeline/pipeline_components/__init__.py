"""The pipeline Components define the different steps of they pipeline. Each component should inherit from one of the following types of components.

### Components types:
- InputComponent: reads data from filesystem is the starting point of every pipeline
- OutputComponent: writes the transformed data to the file system, endpoint of every pipeline
- InnerComponent: defines one transformation that can be applied in a pipeline
further documentation on the attributes of a component can be found in `datapipeline.pipeline_components.component`
"""