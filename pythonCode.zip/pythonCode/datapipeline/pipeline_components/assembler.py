from pythonCode.datapipeline.pipeline_components.component import OutputComponent
from abc import ABC, abstractmethod
import pandas as pd
from typing import Dict
import torch
from pythonCode.datapipeline.FileWriter import FileWriter
import os
class AssemblingStrategy(ABC):
    """Abstract base class for assembling strategies."""
    
    def __init__(self, filewriter: FileWriter) -> None:
        """
        Initializes the AssemblingStrategy with a file writer.

        Args:
            filewriter (FileWriter): The file writer to use for outputting assembled data.
        """
        self._filewriter = filewriter
        
    @abstractmethod
    def assemble(self, *args, **kwargs):
        """
        Assemble data. This method should be overridden by subclasses.

        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        pass
    
    def df_to_tensor_dict(self, df: pd.DataFrame) -> Dict[str, torch.Tensor]:
        """
        Convert a dataframe to a dictionary of tensors.

        Args:
            df (pd.DataFrame): The dataframe to convert.

        Returns:
            Dict[str, torch.Tensor]: A dictionary where keys are column names and values are tensors.
        """
        tensor_dict = {}
        for column in df.columns:
            tensor_dict[column] = torch.tensor(df[column].values, dtype=torch.float32)
        return tensor_dict

class TestValAssembler(AssemblingStrategy):
    """Assembling strategy for test and validation data."""
    
    def assemble(self, destination: str, filename:str, df: pd.DataFrame, **kwargs) -> None:
        """
        Assemble test and validation data and write to a file.

        Args:
            destination (str): The file path where assembled data should be written.
            df (pd.DataFrame): The dataframe containing data to be assembled.
            **kwargs: Additional keyword arguments for assembling.
        """
        df = self.df_to_tensor_dict(df)
        i_scaled = torch.column_stack((df["id_norm"], df["iq_norm"]))
        psi = torch.column_stack((df["psid"], df["psiq"]))
        l = torch.column_stack((df["ldd"], df["ldq"], df["lqd"], df["lqq"]))
        r = df["r"]
        i = torch.column_stack((df["id"], df["iq"]))
        omega_el = df["omega_el"]
        
        assembled_data = {"i_scaled": i_scaled, "psi": psi, "l": l, "r": r, "i": i, "omega_el": omega_el}
        self._filewriter.write(os.path.join(destination,filename), assembled_data)

class TrainAssembler(AssemblingStrategy):
    """Assembling strategy for training data."""
    
    @staticmethod
    def composite_trapezoidal_rule_discrete(x: torch.Tensor) -> torch.Tensor:
        """
        Compute the integral using the composite trapezoidal rule.

        Args:
            x (torch.Tensor): The tensor to integrate.

        Returns:
            torch.Tensor: The computed integral.
        """
        integral = (x[:, 0] * 0.5 + x[:, -1] * 0.5 + x[:, 1:-1].sum(dim=1)) / (x.size(1) - 1)
        return integral
  
    def assemble(self, destination: str,filename:str, df: pd.DataFrame, n: int = None, u_mapping: str = None, **kwargs) -> None:
        """
        Assemble training data and write to a file.

        Args:
            destination(str): The file path where assembled data should be written.
            df (pd.DataFrame): The dataframe containing data to be assembled.
            n (int, optional): The number of points for unfolding.
            u_mapping (str, optional): The mapping strategy for 'u' values. Can be None, 'previous', or 'next'.
            **kwargs: Additional keyword arguments for assembling.

        Raises:
            ValueError: If u_mapping is not None, 'previous', or 'next'.
        """
        df = self.df_to_tensor_dict(df)
        if u_mapping not in [None, "previous", "next"]:
            raise ValueError("'u_mapping should either be None, 'previous' or 'next'")
        else:
            self.u_mapping = u_mapping
            
        if self.u_mapping is None:
            omega_el_unfolded = df["omega_el"].unfold(0, n + 1, n)
            id_norm_unfolded = df["id_norm"].unfold(0, n + 1, n)
            iq_norm_unfolded = df["iq_norm"].unfold(0, n + 1, n)
            ud_unfolded = df["ud"].unfold(0, n + 1, n)
            uq_unfolded = df["uq"].unfold(0, n + 1, n)
            id_unfolded = df["id"].unfold(0, n + 1, n)
            iq_unfolded = df["iq"].unfold(0, n + 1, n)
                
            u = torch.column_stack((self.composite_trapezoidal_rule_discrete(ud_unfolded), self.composite_trapezoidal_rule_discrete(uq_unfolded)))
            i = torch.column_stack((self.composite_trapezoidal_rule_discrete(id_unfolded), self.composite_trapezoidal_rule_discrete(iq_unfolded)))
                
            delta_t = df["Time"][n::n] - df["Time"][:-n:n]
            x_train = torch.stack((id_norm_unfolded, iq_norm_unfolded), dim=-1)
            y_train = torch.column_stack([u, i, delta_t, omega_el_unfolded])
        else:
            if self.u_mapping == "next":
                u = torch.column_stack((df["ud"], df["uq"]))[:-1, :]
                omega_el = df["omega_el"][:-1]
            elif self.u_mapping == "previous":
                u = torch.column_stack((df["ud"], df["uq"]))[1:, :]
                omega_el = df["omega_el"][1:]
            else:
                raise ValueError("u_mapping must be either 'next' or 'previous' or None")
                
            i = torch.column_stack((df["id"][:-1], df["iq"][:-1], df["id"][1:], df["iq"][1:]))
            delta_t = df["Time"][1:] - df["Time"][:-1]
            x_train = torch.column_stack((df["id_norm"][:-1], df["iq_norm"][:-1], df["id_norm"][1:], df["iq_norm"][1:]))
            y_train = torch.column_stack((u, i, omega_el, delta_t))
        
        assembled_data = {"X": x_train, "Y": y_train}
        self._filewriter.write(os.path.join(destination,filename), assembled_data)

class Assembler(OutputComponent):
    """Component for assembling data using a specified strategy."""
    
    def __init__(self, strategy: AssemblingStrategy):
        """
        Initializes the Assembler with a specified strategy.

        Args:
            strategy (AssemblingStrategy): The strategy to use for assembling data.
        """
        self._strategy = strategy
        self.metadata = {}
        
    def execute(self, df: pd.DataFrame, destination: str, filename:str, **kwargs):
        """
        Execute the assembling strategy to assemble data and write to a file.

        Args:
            data (pd.DataFrame): The dataframe containing data to be assembled.
            destination (str): The file path where assembled data should be written.
            filename (str): the name of the file data should be written to.
            **kwargs: Additional keyword arguments for assembling.
        """
        if "n" in kwargs.keys():
            self.metadata["n"] = kwargs["n"]
        self._strategy.assemble(destination=destination, df=df,filename=filename, **kwargs)
        
    def get_metadata(self) -> Dict:
        """
        Retrieve metadata related to the component.

        Returns:
            Dict: A dictionary containing metadata.
        """
        return self.metadata
    
    def get_artifacts(self) -> Dict:
        """
        Retrieve artifacts generated by the component.

        Returns:
            Dict: An empty dictionary (no artifacts generated).
        """
        return {}