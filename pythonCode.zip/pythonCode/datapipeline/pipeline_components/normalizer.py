from pythonCode.datapipeline.pipeline_components.component import InnerComponent
from sklearn.preprocessing import StandardScaler
import pandas as pd
import logging
from typing import Dict

class Normalizer(InnerComponent):
    """Component for normalizing specified columns in a dataframe."""
    
    def __init__(self, keys: list[str]):
        """
        Initializes the Normalizer with specified keys to normalize.

        Args:
            keys (list[str]): The list of column names to be normalized.
        """
        self.scaler = StandardScaler()
        self.keys = keys
        self.transformed_keys = [f"{key}_norm" for key in keys]
        
    def execute(self, df: pd.DataFrame, fit: bool = False) -> pd.DataFrame:
        """
        Normalize specified columns in the dataframe.

        Args:
            df (pd.DataFrame): The dataframe to be normalized. Must contain columns specified in keys.
            fit (bool): Whether to fit the scaler to the data. If False, uses the existing scaler.

        Returns:
            pd.DataFrame: The dataframe with normalized columns.

        Raises:
            ValueError: If the dataframe does not contain the specified columns.
        """
        if not set(self.keys).issubset(df.columns):
            logging.error(f"DataFrame must contain columns: {self.keys}")
            raise ValueError(f"DataFrame must contain columns: {self.keys}")
        
        logging.info("Normalizing DataFrame columns")
        
        # Perform normalization
        if fit:
            df[self.transformed_keys] = self.scaler.fit_transform(df[self.keys])
            logging.info("Fitted and transformed the DataFrame columns")
        else:
            df[self.transformed_keys] = self.scaler.transform(df[self.keys])
            logging.info("Transformed the DataFrame columns using existing scaler")
    
        return df
        
    def get_artifacts(self) -> Dict:
        """
        Returns the scaler used for normalization.

        Returns:
            Dict: A dictionary containing the scaler used for normalization.
        """
        return {"scaler": self.scaler}
    
    def get_metadata(self) -> Dict:
        """
        Retrieve metadata related to the component.

        Returns:
            Dict: An empty dictionary (no metadata generated).
        """
        return {}