import pandas as pd
import os

data_name = "Rekorder_2025-02-04_12-54-39.csv"

def combine_data(data_name: str) ->pd.DataFrame:
    temp_file = data_name.replace("Rekorder","temp")
    speed_file = data_name.replace("Rekorder","speed")

    data = pd.read_csv(f"./data/prüfstand/raw_records/{data_name}")
    data_temp = pd.read_csv(f"./data/prüfstand/raw_temp/{temp_file}")
    data_speed = pd.read_csv(f"./data/prüfstand/raw_speed/{speed_file}")

    data.set_index('Time',inplace=True)
    data_temp.set_index("Time",inplace=True)
    data_speed.set_index("Time",inplace=True)
    orignial_indexes = data.index

    df_combined = pd.concat([data,data_temp,data_speed]).sort_index()
    df_combined = df_combined.interpolate(method='index')
    df_combined = df_combined[df_combined.index.isin(orignial_indexes)]
    return df_combined
    
def batch_process() -> None:
    files = os.listdir("./data/prüfstand/raw_records")
    for file in files:
        combined = combine_data(file)
        combined.to_csv(f"./data/prüfstand/preprocessed/{file}")
        
if __name__ == "__main__":
    df= combine_data(data_name)
    df.to_csv(f"./data/prüfstand/preprocessed/{data_name}")
    