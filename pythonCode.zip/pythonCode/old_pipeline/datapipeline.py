from prefect import task,flow
import numpy as np
import pandas as pd
from typing import Dict,List,Tuple
from sklearn.preprocessing import StandardScaler
import torch
import joblib
import os


@task
def load_data_from_file(data_name:str) -> List[pd.DataFrame]:
    sim_data = pd.read_csv(f"./data/raw/{data_name}.csv")
    validation_data = pd.read_csv(f"./data/raw/validationdata.csv")
    metadata = pd.read_csv(f"./data/raw/{data_name}_metadata.csv",index_col=None)
    
    return [sim_data,validation_data,metadata]

def load_csv_files(files:List[str]) -> List[pd.DataFrame]:
    dataframes = []
    for file in files:
        dataframes.append(pd.read_csv(file))
    return dataframes

@task
def filter_for_current_limit(val : pd.DataFrame,limit)->pd.DataFrame:
    i = val[["id","iq"]].values
    condition = i[:,0]**2+i[:,1]**2 < limit**2
    filtered_indices = np.where(condition)[0]
    val_filtered = val.iloc[filtered_indices]
    
    return val_filtered

@task
def filter_for_dynamic(x_train :torch.Tensor, y_train : torch.Tensor,lower_limit:int,upper_limit:int) -> Tuple[torch.Tensor]:
    # lower boundary
    lower_condition = torch.sqrt(torch.square(y_train[:,2]-y_train[:,4]) + torch.square(y_train[:,3]-y_train[:,5])) > lower_limit
    upper_condition = torch.sqrt(torch.square(y_train[:,2]-y_train[:,4]) + torch.square(y_train[:,3]-y_train[:,5])) < upper_limit
    dynamic_condition = lower_condition & upper_condition
    indices = torch.nonzero(dynamic_condition, as_tuple=True)
    return x_train[indices],y_train[indices]

@task
def normalize_currents(x:pd.DataFrame,*args:pd.DataFrame)-> List[pd.DataFrame]:
    keys = ["id","iq"]
    transformed_keys = ["id_norm","iq_norm"]
    scaler = StandardScaler()
    x[transformed_keys] = scaler.fit_transform(x[keys])
    
    transformed_dfs = [x]
    for df in args:
        df[transformed_keys] = scaler.transform(df[keys])
        transformed_dfs.append(df)
    
    return transformed_dfs, scaler

@task
def assemble_val_data(val:pd.DataFrame,r,omega_el) -> Dict[str,torch.Tensor]:
    i_validation_scaled = torch.from_numpy(val[["id_norm","iq_norm"]].values).float()
    psi_validation = torch.tensor(val[["psid","psiq"]].values)
    l_validation = torch.tensor(val[["ldd","ldq","lqd","lqq"]].values)
    r_validation = torch.ones((len(val),))*r
    i_validation = torch.from_numpy(val[["id","iq"]].values).float()
    return {"i_scaled":i_validation_scaled,"psi":psi_validation,"l":l_validation,"r":r_validation,"i":i_validation,"omega_el":omega_el}

@task
def assemble_test_data(test:pd.DataFrame,r,omega_el) -> Dict[str,torch.Tensor]:
    i_test_scaled = torch.from_numpy(test[["id_norm","iq_norm"]].values).float()
    psi_test = torch.tensor(test[["psid","psiq"]].values)
    l_test = torch.tensor(test[["ldd","ldq","lqd","lqq"]].values)
    r_test = torch.ones((len(test),))*r
    i_test = torch.from_numpy(test[["id","iq"]].values).float()
    return {"i_scaled":i_test_scaled,"psi":psi_test,"l":l_test,"r":r_test,"i":i_test,"omega_el":omega_el}

@task
def assemble_data(train:pd.DataFrame,val:pd.DataFrame,test:pd.DataFrame,u_mapping:str = "next") ->List[Dict[str,torch.Tensor]]:
    #training data
    i = torch.from_numpy(np.column_stack((train[["id","iq"]].values[:-1,:],train[["id","iq"]].values[1:,:]))).float()
    if u_mapping == "next":
        u = torch.from_numpy(train[["ud","uq"]].values[:-1,:]).float()
        omega_el = torch.tensor(train["omega_el"].values[:-1]).float()
    elif u_mapping == "previous":
        u = torch.from_numpy(train[["ud","uq"]].values[1:,:]).float()
        omega_el = torch.tensor(train["omega_el"].values[1:]).float()
    else:
        ValueError("u_mapping must be either 'next' or 'previous'")
        
    delta_t = torch.tensor(train["Time"][1:].values-train["Time"].values[:-1])
    x_train = torch.from_numpy(np.column_stack((train[["id_norm","iq_norm"]].values[:-1,:],train[["id_norm","iq_norm"]].values[1:,:]))).float()
    y_train = torch.column_stack([u,i,omega_el,delta_t])
    
    #validation data
    val_dict = assemble_val_data(val,train["r"][0],omega_el)

    #test data
    test_dict = assemble_test_data(test,train["r"][0],omega_el)
    
    return [{"X":x_train,"Y":y_train},
            val_dict,
            test_dict]
@task
def df_to_tensor_dict(df: pd.DataFrame) -> Dict[str, torch.Tensor]:
    tensor_dict = {}
    for column in df.columns:
        tensor_dict[column] = torch.tensor(df[column].values).float()
    return tensor_dict

@task
def assemble_discrete_data_trapezoidal(train:pd.DataFrame,val:pd.DataFrame,test:pd.DataFrame,n:int,threshold:int) ->List[Dict[str,torch.Tensor]]:
    train = df_to_tensor_dict(train)
    
    omega_el_unfolded = train["omega_el"].unfold(0, n+1, n)
    id_norm_unfolded = train["id_norm"].unfold(0, n+1, n)
    iq_norm_unfolded = train["iq_norm"].unfold(0, n+1, n)
    ud_unfolded = train["ud"].unfold(0, n+1, n)
    uq_unfolded = train["uq"].unfold(0, n+1, n)
    id_unfolded = train["id"].unfold(0, n+1, n)
    iq_unfolded = train["iq"].unfold(0, n+1, n)
    diff_u1 = ud_unfolded.max(dim=1).values - ud_unfolded.min(dim=1).values
    diff_u2 = uq_unfolded.max(dim=1).values - uq_unfolded.min(dim=1).values
    
    mask = (diff_u1 <= threshold) & (diff_u2 <= threshold)
    u = torch.column_stack((composite_trapezoidal_rule_discrete(ud_unfolded[mask]),composite_trapezoidal_rule_discrete(uq_unfolded[mask])))
    i = torch.column_stack((composite_trapezoidal_rule_discrete(id_unfolded[mask]),composite_trapezoidal_rule_discrete(iq_unfolded[mask])))
    t = train["Time"][n::n] - train["Time"][:-n:n]
        
    x_train = torch.stack((id_norm_unfolded[mask],iq_norm_unfolded[mask]),dim=-1)
    y_train = torch.column_stack([u,i,t[mask],omega_el_unfolded[mask]])
    
    #validation data
    val_dict = assemble_val_data(val,train["r"][0],omega_el_unfolded[mask])

    #test data
    test_dict = assemble_test_data(test,train["r"][0],omega_el_unfolded[mask])
    
    return [{"X":x_train,"Y":y_train},
            val_dict,
            test_dict]
        
@task
def composite_trapezoidal_rule_discrete(x: torch.Tensor) -> torch.Tensor:
    integral = (x[:, 0] * 0.5 + x[:, -1] * 0.5 + x[:, 1:-1].sum(dim=1)) / (x.size(1) - 1)
    return integral       

@task
def assemble_stat_data(train:pd.DataFrame,val:pd.DataFrame,test:pd.DataFrame) ->List[Dict[str,torch.Tensor]]:
    #training data
    i = torch.from_numpy(train[["id","iq"]].values).float()
    u = torch.from_numpy(train[["ud","uq"]].values).float()

    omega_el = torch.tensor(train["omega_el"].values).float()
    x_train = torch.from_numpy(train[["id_norm","iq_norm"]].values).float()
    y_train = torch.column_stack([u,i,omega_el])
    
    #validation data
    val_dict = assemble_val_data(val,train["r"][0],omega_el)

    #test data
    test_dict = assemble_test_data(test,train["r"][0],omega_el)
    
    return [{"X":x_train,"Y":y_train},
            val_dict,
            test_dict] 
    
@task 
def assemble_dyn_data(train:pd.DataFrame,i_start:pd.DataFrame,i_end:pd.DataFrame,val:pd.DataFrame,test:pd.DataFrame) -> Dict[str,torch.Tensor]:
    #training data
    i = torch.from_numpy(np.column_stack((i_start[["id","iq"]].values,i_end[["id","iq"]].values))).float()
    u = torch.from_numpy(train[["ud","uq"]].values).float()
    omega_el = torch.tensor(train["omega_el"].values).float()
        
    delta_t = torch.tensor(train["delta_t"].values)
    x_train = torch.from_numpy(np.column_stack((i_start[["id_norm","iq_norm"]].values,i_end[["id_norm","iq_norm"]].values))).float()
    y_train = torch.column_stack([u,i,omega_el,delta_t])
    
    #validation data
    val_dict = assemble_val_data(val,train["r"][0],omega_el)

    #test data
    test_dict = assemble_test_data(test,train["r"][0],omega_el)
    
    return [{"X":x_train,"Y":y_train},
            val_dict,
            test_dict]
@task  
def write_to_disk(train,val,test,meta:pd.DataFrame,scaler:StandardScaler,data_name:str)->None:
    # Define the folder path
    folder_path = f"./data/clean/{data_name}"

    # Check if the folder exists, otherwise create it
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"Folder '{folder_path}' created.")
    else:
        print(f"Folder '{folder_path}' already exists.")
        
    torch.save(train,f"./data/clean/{data_name}/train.pt")
    torch.save(val,f"./data/clean/{data_name}/validation.pt")
    torch.save(test,f"./data/clean/{data_name}/test.pt")
    meta.to_csv(f"./data/clean/{data_name}/metadata.csv",index=False)
    joblib.dump(scaler,f"./data/clean/{data_name}/scaler.pkl")
    
@task
def scan_for_new_files(path:str):
    data_names = []
    raw_files = os.listdir(os.path.join("./data/raw",path))
    clean_files = os.listdir(os.path.join("./data/clean",path))
    
    clean_files_set = {os.path.splitext(clean_file)[0] for clean_file in clean_files}
    
    for raw_file in raw_files:
        if "test" not in raw_file and "metadata" not in raw_file and "validation" not in raw_file:
            data_name, ext = os.path.splitext(raw_file)
            if ext == ".csv" and data_name not in clean_files_set:
                data_names.append(data_name)

    for i,data_name in enumerate(data_names):
        data_names[i] = os.path.join(path,data_name)
    return data_names
        
@flow
def preprocess_data_file(dataname_in,dataname_out=None,test_current_limit=None,mapping_direction="previous"):
    if dataname_out is None:
        dataname_out = dataname_in
    # 1. step load data
    train,val,meta = load_data_from_file(dataname_in)
    #train["r"] = 0.0231
    # 2. step filter for a maximum current
    max_training_current = np.max(np.sqrt(train["id"].values**2+train["iq"].values**2))
    val_filtered = filter_for_current_limit(val,max_training_current)
    if test_current_limit is None:
        test_current_limit = max_training_current
    test = filter_for_current_limit(val,test_current_limit)
    
    # 3.step normalize the currents
    transformed_dfs,scaler = normalize_currents(train,val_filtered,test)
    train,val,test = transformed_dfs
    # 4.step write back to disk
    train,val,test = assemble_data(train,val,test,mapping_direction)
    write_to_disk(train,val,test,meta,scaler,dataname_out)
    
@task
def load_pruefstand_data_file(dataname_in):
    train,val = load_csv_files([f"./data/prüfstand/cut/{dataname_in}.csv","./data/prüfstand/LUT/lwr_tables.csv"])
    rename_dict = {"IQAI_V_VoltNormBase_Ie":"v_norm",
            "IQCC_r_VdCmd_Ie":"ud",
            "IQCC_r_VqCmd_Ie":"uq",
            "IQCP_I_IdMeasRaw_Ie":"id",
            "IQCP_I_IqMeasRaw_Ie":"iq",
            "IQPP_w_SpdElecRaw_Ve":"omega_el"}
    train.rename(columns=rename_dict, inplace=True)
    
    return train,val
@flow
def preprocess_pruefstand_data_file(dataname_in,dataname_out=None,dynamic_lower_threshold = 0,dynamic_upper_threshold = torch.inf):
    if dataname_out is None:
        dataname_out = dataname_in
    # 1. step load data
    train,val = load_pruefstand_data_file(dataname_in)
    meta = pd.DataFrame({"dynamic_lower_threshold":[dynamic_lower_threshold]})

    train["r"] = 0.0128
    train["ud"] = train["ud"]*train["v_norm"]
    train["uq"] = train["uq"]*train["v_norm"]
    # 2. step filter for a maximum current
    max_training_current = np.max(np.sqrt(train["id"].values**2+train["iq"].values**2))
    val_filtered = filter_for_current_limit(val,max_training_current)
    test = filter_for_current_limit(val,max_training_current)
    
    # 3.step normalize the currents
    transformed_dfs,scaler = normalize_currents(train,val_filtered,test)
    train,val,test = transformed_dfs

    # 4.step assemble data
    train,val,test = assemble_data(train,val,test,"next")
    
    #5. step filter for a minum delta_i in each sample
    x_train,y_train = filter_for_dynamic(train["X"],train["Y"],dynamic_lower_threshold,dynamic_upper_threshold)
    train = {"X":x_train,"Y":y_train}
    # 4.step write back to disk
    write_to_disk(train,val,test,meta,scaler,dataname_out)

@flow
def preprocess_stationary_data_file(dataname_in,dataname_out=None):
    if dataname_out is None:
        dataname_out = dataname_in
    # 1. step load data
    train,val = load_csv_files([f"./data/prüfstand/cut/{dataname_in}.csv","./data/prüfstand/LUT/lwr_tables.csv"])
    train["omega_el"] = 418.879
    train["r"] = 0.0128
    meta=pd.DataFrame()
    # 2. step filter for a maximum current
    max_training_current = np.max(np.sqrt(train["id"].values**2+train["iq"].values**2))
    val_filtered = filter_for_current_limit(val,max_training_current)
    test = filter_for_current_limit(val,max_training_current)
    
    # 3.step normalize the currents
    transformed_dfs,scaler = normalize_currents(train,val_filtered,test)
    train,val,test = transformed_dfs

    # 4.step assemble data
    train,val,test = assemble_stat_data(train,val,test)
    
    # 4.step write back to disk
    write_to_disk(train,val,test,meta,scaler,dataname_out)
    
@flow
def preprocess_dynamic_data_file(dataname_in,dataname_out=None,test_current_limit=None):
    if dataname_out is None:
        dataname_out = dataname_in
    #1.step load data from disk
    train,val,meta = load_csv_files([f"./data/raw/{dataname_in}.csv","./data/raw/validationdata.csv",f"./data/raw/{dataname_in}_metadata.csv"])
    
    #2. step filter currents for max current
    max_training_current = np.max([np.sqrt(train["id_start"].values**2+train["iq_start"].values**2),np.sqrt(train["id_end"].values**2+train["iq_end"].values**2)])
    val_filtered = filter_for_current_limit(val,max_training_current)
    if test_current_limit is None:
        test_current_limit = max_training_current
    test = filter_for_current_limit(val,test_current_limit)
    
    #3.step normalize currents
    start_i = train[["id_start","iq_start"]]
    start_i.columns = ["id","iq"]
    end_i = train[["id_end","iq_end"]]
    end_i.columns= ["id","iq"]
    transformed_dfs,scaler = normalize_currents(start_i,end_i,val_filtered,test)
    start_i,end_i,val,test = transformed_dfs
    
    #4.step assemble data
    train,val,test = assemble_dyn_data(train,start_i,end_i,val,test)
    
    #5.step write back to disk
    write_to_disk(train,val,test,meta,scaler,dataname_out)
   
@flow
def preprocess_data_file_general(dataname_in,dataname_out=None,n=1,u_threshold=torch.inf):
    if dataname_out is None:
        dataname_out = dataname_in
    #1.step load data from disk
    train,val,meta = load_csv_files([f"./data/raw/{dataname_in}.csv","./data/raw/validationdata.csv",f"./data/raw/{dataname_in}_metadata.csv"])
    train,val,test,meta,scaler = transform_data_general(train,val,meta,n,u_threshold)
    #5.step write back to disk
    write_to_disk(train,val,test,meta,scaler,dataname_out)
    
@flow
def preprocess_pruefstand_data_file_general(dataname_in,dataname_out=None,n=1):
    if dataname_out is None:
        dataname_out = dataname_in
    #1.step load data from disk
    train,val = load_csv_files([f"./data/prüfstand/cut/{dataname_in}.csv","./data/prüfstand/LUT/lwr_tables.csv"])
    train["r"] = 0.0128
    train,val,test,meta,scaler = transform_data_general(train,val,n=n)
    #5.step write back to disk
    write_to_disk(train,val,test,meta,scaler,dataname_out)
     
@task   
def transform_data_general(train,val,meta=None,n=1,delta_u_limit = torch.inf):
    if meta is None:
        meta = pd.DataFrame({"n":[n],"u_limit":[delta_u_limit]})
    else:
        meta["n"] = n
        meta["u_limit"] = delta_u_limit
    # 2. step filter for a maximum current
    max_training_current = np.max(np.sqrt(train["id"].values**2+train["iq"].values**2))
    val_filtered = filter_for_current_limit(val,max_training_current)
    test = filter_for_current_limit(val,max_training_current)
    
    # 3.step normalize the currents
    transformed_dfs,scaler = normalize_currents(train,val_filtered,test)
    train,val,test = transformed_dfs
    
    #4.step assemble data
    train,val,test = assemble_discrete_data_trapezoidal(train,val,test,n,delta_u_limit)
    return train,val,test,meta,scaler
       
@flow
def batch_preprocess(path:str):
    datanames = scan_for_new_files(path)
    for dataname in datanames:
        preprocess_data_file(dataname)
        
    
        
if __name__ == "__main__":
    #preprocess_dynamic_data_file("sampling/dynamic_sampling_100khzbase",test_current_limit=600)
    #preprocess_data_file("sampling/sim_meas_8khz_10mhz_hold0_001")
    preprocess_data_file("noise/noise_90","old_pipeline_ref")
    #batch_preprocess("sampling")
    #preprocess_data_file_general("sampling/sim_meas_50khz_raw","sampling/50khz_trapezoidal_n5000",n=5000)
    #preprocess_pruefstand_data_file_general("dewe_raw","dewe_raw_n5000",n=5000)
    #preprocess_data_file_general("sampling/sim_meas_50khz_raw","sampling/50khz_trapezoidal_n1_u1",n=1,u_threshold=1)
    