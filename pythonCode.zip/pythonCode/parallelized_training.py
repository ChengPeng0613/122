import os
import sys

# Dynamically set the PYTHONPATH to include the project directory
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)
    
import torch.multiprocessing as mp
import psutil
import pandas as pd
import joblib
from torch.utils.data import TensorDataset
import joblib
from torch.utils.data import DataLoader, TensorDataset
from pythonCode.steps.eval import *
from pythonCode.steps.logging import custom_log, get_or_create_run
from pythonCode.steps.compute import *
from pythonCode.steps.costum_plots import *
from pythonCode.steps.training import do_training_step
from pythonCode.steps.eval import *
from pythonCode.steps.plot import *
from pythonCode.steps.model import *
import pandas as pd
from pythonCode.steps.eval import *
from pythonCode.steps.loss import custom_loss_general,custom_loss

def train(experiment,data_name,max_epochs,batchsize,runs_per_size):
    train_path =f"./data/clean/{data_name}/train.pt"
    validation_path = f"./data/clean/{data_name}/validation.pt"
    test_path = f"./data/clean/{data_name}/test.pt"
    metadata_path = f"./data/clean/{data_name}/metadata.csv"
    scaler_path = f"./data/clean/{data_name}/scaler.pkl"

    #load data
    train_data = torch.load(train_path)
    validation_data = torch.load(validation_path)
    test_data = torch.load(test_path)
    try:
        metadata = pd.read_csv(metadata_path,index_col=None)
        if metadata.empty:
            print("Die CSV-Datei ist leer. Ein leeres DataFrame wurde erstellt.")
        else:
            print("Die CSV-Datei wurde erfolgreich gelesen.")
    except pd.errors.EmptyDataError:
        metadata = pd.DataFrame()
        print("Die CSV-Datei ist leer. Ein leeres DataFrame wurde erstellt.")

    #assume constant parameters
    R = validation_data["r"][0]

    #loader scaler
    scaler = joblib.load(scaler_path)

    train_dataset = TensorDataset(train_data["X"],train_data["Y"]) 

    # Define constants and initialize variables
    parent_run_name=f"baseline {data_name}"
    parent_run_id= get_or_create_run(experiment.experiment_id,parent_run_name)

    for i in range(runs_per_size):
        with mlflow.start_run(run_name=f"run {i} {data_name}",nested=True,parent_run_id=parent_run_id):
            lr = 0.001
            mlflow.log_param("num_datapoints",len(train_data["X"]))
            mlflow.log_params(metadata.iloc[0])
            dataset_info= {"dataset":data_name,"random sampling":True}
            model_parameters= {"activation":"Tanh","lr":lr,"batch_size":batchsize,"num_trained_epochs":max_epochs,"use_batchnorm":False}
            neurons_per_layer = [20,20,20]
            for i,neurons in enumerate(neurons_per_layer):
                model_parameters[f"neurons_layer_{i}"] = neurons
                
            eval_loss_fn = torch.nn.L1Loss()
            model = FluxModel(neurons_per_layer,model_parameters["use_batchnorm"])
            optimizer = torch.optim.Adam(model.parameters(),lr=lr)
            train_loader = DataLoader(train_dataset,batch_size=batchsize,shuffle=dataset_info["random sampling"])
            custom_log(dataset_info, model_parameters,train_path,validation_path,test_path,scaler_path)

            for epoch in range(max_epochs):
                for x,y in train_loader:
                    # Training step
                    loss = do_training_step(model, optimizer, x,y,custom_loss)
                
                val_loss = validatemodel(model,validation_data,R,eval_loss_fn, epoch,loss)
                #lr_scheduler.step()
                if epoch % 5 == 0:
                    inputs = validation_data["i_scaled"].clone().detach().requires_grad_(True)
                    pred,r = model(inputs)
                    inductances = compute_differential_inductances_fast(pred,inputs,scaler)
                    l_loss = eval_loss_fn(inductances,validation_data["l"])
                    
                    true_state_space_parameters = torch.column_stack(physical_parameters_to_state_space(validation_data["psi"],validation_data["l"],validation_data["r"][0],validation_data["omega_el"][0]))
                    estimated_state_space_parameter= torch.column_stack(physical_parameters_to_state_space(pred,inductances,r.item(),validation_data["omega_el"][0]))
                    state_space_loss = eval_loss_fn(estimated_state_space_parameter,true_state_space_parameters)
                    mlflow.log_metrics({"val_l_mae":l_loss,"val_state_space_mae":state_space_loss}, step=epoch)


                    
            #log results
            inputs = validation_data["i_scaled"].clone().detach().requires_grad_(True)
            pred,r = model(inputs)
            inductances = compute_differential_inductances_fast(pred,inputs,scaler)
            l_loss = eval_loss_fn(inductances,validation_data["l"])
            log_l_visualization(inductances,validation_data)
            log_psi_error_plane(pred.detach(),validation_data)
            log_l_error_plane(inductances,validation_data)
            log_prediction_visualization(pred.detach(),validation_data)
            log_l_3d_subplot(inductances,validation_data)
            log_psi_3d_subplot(pred.detach(),validation_data)
            mlflow.pytorch.log_model(model,"model")
            true_state_space_parameters = torch.column_stack(physical_parameters_to_state_space(validation_data["psi"],validation_data["l"],validation_data["r"][0],validation_data["omega_el"][0]))
            estimated_state_space_parameter= torch.column_stack(physical_parameters_to_state_space(pred.detach(),inductances,r.item(),validation_data["omega_el"][0]))
            log_state_space_parameters_error_plane(true_state_space_parameters,estimated_state_space_parameter,validation_data)
            log_ss_3d_subplot(pred=estimated_state_space_parameter,true=true_state_space_parameters,validation_data=validation_data)


def main():     
    # Get the number of logical CPUs (vCPUs)
    num_vcpus = psutil.cpu_count(logical=True)

    #connect to mlflow
    mlflow.set_tracking_uri("http://cmtcdeu82827824:5000")
    experiment = mlflow.set_experiment("sampling")


    #datasets = ["noise/noise_u_01","noise/noise_u_00001"]#,"noise/noise_u_00001"]
    datasets = ["sampling/sim_meas_8khz_10mhz_hold_0_01"]#,"sampling/sim_meas_8khz_1mhz"]
    # Number of processes to use
    world_size = len(datasets)

    # Number of epochs and batch size
    epochs = 101
    batch_size = 128

    torch.set_num_threads(int(num_vcpus/world_size)-1)
    # Spawn processes
    processes = []
    for rank in range(world_size):
        p = mp.Process(target=train, args=(experiment,datasets[rank], epochs, batch_size,15))
        p.start()
        processes.append(p)

    print(processes)
    for p in processes:
        p.join()
        
if __name__ == "__main__":

    main()