""" build an run a pipeline"""
import os
import sys

# Dynamically set the PYTHONPATH to include the project directory
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

import logging
from pythonCode.datapipeline.Pipeline import Pipeline
from pythonCode.datapipeline.DataLoader import DataLoader, LoadSimFiles,LoadTestbenchFile
from pythonCode.datapipeline.FileLoader import FileLoader
from pythonCode.datapipeline.FileWriter import FileWriter
from pythonCode.datapipeline.pipeline_components import normalizer,Filter,FillMissingData,assembler,rename_columns
from pythonCode.datapipeline.PipelineExecutor import PipelineExecutor

#set log level
logging.basicConfig(level=logging.INFO)

#initialize components
file_writer = FileWriter()
file_loader = FileLoader()
sim_dataloader = DataLoader(LoadSimFiles(file_loader))
testbench_dataloader = DataLoader(LoadTestbenchFile(file_loader))
scaler = normalizer.Normalizer(["id","iq"])
currentFilter = Filter.CurrentLimitFilter()
train_assembler = assembler.Assembler(assembler.TrainAssembler(file_writer)) 
testval_assembler = assembler.Assembler(assembler.TestValAssembler(file_writer))
sim_filler = FillMissingData.FillMissingData(FillMissingData.FillSim())
testbench_filler = FillMissingData.FillMissingData(FillMissingData.FillTestbench())
renamer = rename_columns.RenameColumns()

#build
# pipeline
sim_train_pipeline = Pipeline(components=[currentFilter,scaler,train_assembler],filewriter=file_writer)
sim_val_pipeline = Pipeline(components=[sim_filler,currentFilter,scaler,testval_assembler],filewriter=file_writer)
test_pipeline = sim_val_pipeline
sim_pipelines = {"train":sim_train_pipeline,
                 "val":sim_val_pipeline,
                 "test":test_pipeline}
pipeline_data_mapping = {"train":"data",
                         "val":"validation",
                         "test":"validation"}

#build sim pipeline executor
sim_pipeline_executor = PipelineExecutor(sim_pipelines,file_writer,sim_dataloader,pipeline_data_mapping)

#add arguments for each component in each pipeline
sim_train_args = {"CurrentLimitFilter":{"compute_max_current":True},
                  "Normalizer":{"fit":True},
                  "Assembler":{"filename":"train.pt","u_mapping":"previous"}}
sim_test_args = {"CurrentLimitFilter":{"compute_max_current":False},
                 "Normalizer":{"fit":False},
                 "Assembler":{"filename":"test.pt"}}
sim_val_args = {"CurrentLimitFilter":{"compute_max_current":False},
                 "Normalizer":{"fit":False},
                 "Assembler":{"filename":"validation.pt"}}

#run the sim pipeline
sim_pipeline_executor.run("./data/raw/sampling/sim_meas_8khz_1mhz_hold0_1","./data/clean/sampling/sim_meas_8khz_1mhz_hold0_1",{"train":sim_train_args,"val":sim_val_args,"test":sim_test_args})
