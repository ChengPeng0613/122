""" build an run a pipeline"""
import os
import sys

# Dynamically set the PYTHONPATH to include the project directory
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

import logging
from pythonCode.datapipeline.Pipeline import Pipeline
from pythonCode.datapipeline.DataLoader import DataLoader, LoadSimFiles,LoadTestbenchFile
from pythonCode.datapipeline.FileLoader import FileLoader
from pythonCode.datapipeline.FileWriter import FileWriter
from pythonCode.datapipeline.pipeline_components import normalizer,Filter,FillMissingData,assembler,rename_columns
from pythonCode.datapipeline.PipelineExecutor import PipelineExecutor

#set log level
logging.basicConfig(level=logging.INFO)

#initialize components
file_writer = FileWriter()
file_loader = FileLoader()
sim_dataloader = DataLoader(LoadSimFiles(file_loader))
testbench_dataloader = DataLoader(LoadTestbenchFile(file_loader))
scaler = normalizer.Normalizer(["id","iq"])
currentFilter = Filter.CurrentLimitFilter()
train_assembler = assembler.Assembler(assembler.TrainAssembler(file_writer)) 
testval_assembler = assembler.Assembler(assembler.TestValAssembler(file_writer))
sim_filler = FillMissingData.FillMissingData(FillMissingData.FillSim())
testbench_filler = FillMissingData.FillMissingData(FillMissingData.FillTestbench())
renamer = rename_columns.RenameColumns()

pipeline_data_mapping = {"train":"data",
                         "val":"validation",
                         "test":"validation"}

#build
# pipeline
testbench_train_pipeline = Pipeline(components=[renamer,currentFilter,scaler,train_assembler],filewriter=file_writer)
testbench_val_pipeline = Pipeline(components=[testbench_filler,currentFilter,scaler,testval_assembler],filewriter=file_writer)
testbench_test_pipeline = testbench_val_pipeline
testbench_pipelines = {"train":testbench_train_pipeline,
                 "val":testbench_val_pipeline,
                 "test":testbench_test_pipeline}

#build testbench pipeline executor
testbench_pipeline_executor = PipelineExecutor(testbench_pipelines,file_writer,testbench_dataloader,pipeline_data_mapping)

#add arguments for each component in each pipeline
testbench_train_args = {"CurrentLimitFilter":{"compute_max_current":True},
                  "Normalizer":{"fit":True},
                  "Assembler":{"filename":"train.pt","u_mapping":"previous"}}
testbench_test_args = {"CurrentLimitFilter":{"compute_max_current":False},
                 "Normalizer":{"fit":False},
                 "Assembler":{"filename":"test.pt"}}
testbench_val_args = {"CurrentLimitFilter":{"compute_max_current":False},
                 "Normalizer":{"fit":False},
                 "Assembler":{"filename":"validation.pt"}}

#run the testbench pipeline
testbench_pipeline_executor.run("./data/prüfstand/cut/Rekorder_2025-02-04_12-09-41","./data/test_testbench_pipeline",
                                {"train":testbench_train_args,"val":testbench_val_args,"test":testbench_test_args})

