
from abc import ABC, abstractmethod
import pandas as pd
from typing import Dict
import torch
import os
import logging
from abc import ABC, abstractmethod
import pandas as pd
from typing import Dict
from typing import Tuple


class Component(ABC):
    @abstractmethod
    def execute(self,data, **kwargs):
        """Process the data. This method should be overridden by subclasses."""
        pass
    
    @abstractmethod
    def get_artifacts(self)->Dict:
        pass
    
    @abstractmethod
    def get_metadata(self)->Dict:
        pass  
    
class InnerComponent(Component):
    @abstractmethod
    def execute(self,df:pd.DataFrame, **kwargs):
        """Process the data. This method should be overridden by subclasses."""
        pass

class OutputComponent(Component):
    @abstractmethod
    def execute(self,path:str,data:pd.DataFrame)->None:
        """Output data to a file. This method should be overriden by subclass"""
        pass
        
class InputComponent(Component):
    @abstractmethod
    def execute(self,path:str)-> Tuple[pd.DataFrame, ...]:
        """Load data from file. This method should br overriden by subclass"""
        pass
class FileLoader():
    def __init__(self):
        self.loaders = {
            '.csv': self._load_csv,
            '.json': self._load_json,
            '.excel': self._load_excel,
            '.mat':self._load_mat,
            '.parquet':self._load_mat
        }

    def execute(self, file_path:str,as_dataframe=False):
        _,file_type = os.path.splitext(file_path)
        if file_type not in self.loaders:
            raise ValueError(f"Unsupported file type: {file_type}")
        data =  self.loaders[file_type](file_path)
        if as_dataframe:
            data = self._convert_to_dataframe(data,file_type)
        return data

    def _load_csv(self, file_path:str) ->pd.DataFrame:
        return pd.read_csv(file_path)

    def _load_json(self, file_path:str)-> json:
        with open(file_path, 'r') as file:
            return json.load(file)

    def _load_excel(self, file_path:str)->pd.DataFrame:
        return pd.read_excel(file_path)
    
    def _load_mat(self,file_path:str)->Dict:
        return loadmat(file_path)
    
    def _load_parquet(self,file_path:str)->pd.DataFrame:
        return pd.read_parquet(file_path)
    
    def _convert_to_dataframe(self,data,file_type:str)->pd.DataFrame:
        if file_type in [".csv",".excel",".parquet"]:
            return data # Already a Dataframe
        elif file_type == ".json":
            return pd.json_normalize(data)
        elif file_type == ".mat":
            data = {k: v for k, v in data.items() if not k.startswith('__')}
            return pd.DataFrame({k: pd.Series(v.flatten()) for k, v in data.items()})
        else:
            raise ValueError(f"Cannot convert file type {file_type} to DataFrame")
    def get_artifacts(self):
        return None
    
import pandas as pd
import joblib
import torch
import os
import logging

class FileWriter():
    def __init__(self):
        self.writers = {
            ".csv": self._write_csv,
            ".pkl": self._write_pkl,
            ".pt": self._write_pt
        }
        
    def write(self,filepath:str,data) ->None:
        dir,_ = os.path.split(filepath)
        self.create_dir_if_not_existant(dir)
        
        _,file_type = os.path.splitext(filepath)
        if file_type not in self.writers:
            raise ValueError(f"Unsupported file type: {file_type}")
        self.writers[file_type](filepath,data)
            
    def _write_csv(self,filepath:str,data:pd.DataFrame) ->None:
        data.to_csv(filepath)
        
    def _write_pkl(self,filepath:str,data) ->None:
        joblib.dump(data,filepath)
    
    def _write_pt(self,filepath:str,data) ->None:
        torch.save(data,filepath)
        
    def create_dir_if_not_existant(self,path:str)->None:
        # Check if the folder exists, otherwise create it
        if not os.path.exists(path):
            os.makedirs(path)
            logging.info(f"Folder '{path}' created.")
        else:
            logging.info(f"Folder '{path}' already exists.")
            
class AssemblingStrategy(ABC):
    def __init__(self,filewriter:FileWriter) ->None:
        self._filewriter = filewriter
        
    @abstractmethod
    def assemble(self,*arg,**kwargs):
        pass
    
    def df_to_tensor_dict(self,df: pd.DataFrame) -> Dict[str, torch.Tensor]:
        tensor_dict = {}
        for column in df.columns:
            tensor_dict[column] = torch.tensor(df[column].values,dtype=torch.float64)
        return tensor_dict
    
    
class TestValAssembler(AssemblingStrategy):
    def assemble(self, path:str,data:pd.DataFrame,**kwargs)->None:
        data  = self.df_to_tensor_dict(data)
        i_scaled = torch.column_stack((data["id_norm"],data["iq_norm"]))
        psi = torch.column_stack((data["psid"],data["psiq"]))
        l = torch.column_stack((data["ldd"],data["ldq"],data["lqd"],data["lqq"]))
        r = data["r"]
        i = torch.column_stack((data["id"],data["iq"]))
        omega_el = data["omega_el"]
        
        assembled_data = {"i_scaled":i_scaled,"psi":psi,"l":l,"r":r,"i":i,"omega_el":omega_el}
        self._filewriter.write(path,assembled_data)
       
        
class TrainAssembler(AssemblingStrategy):
    def composite_trapezoidal_rule_discrete(x: torch.Tensor) -> torch.Tensor:
        integral = (x[:, 0] * 0.5 + x[:, -1] * 0.5 + x[:, 1:-1].sum(dim=1)) / (x.size(1) - 1)
        return integral
  
    def assemble(self, path:str,data:pd.DataFrame,n:int=None,u_mapping:str = None,**kwargs)->None:
        data = self.df_to_tensor_dict(data)
        if u_mapping not in [None,"previous","next"]:
            ValueError("'u_mapping should either be None, 'previous' or 'next'")
        else:
            self.u_mapping = u_mapping
            
        if self.u_mapping is None:
                omega_el_unfolded = data["omega_el"].unfold(0, n+1, n)
                id_norm_unfolded = data["id_norm"].unfold(0, n+1, n)
                iq_norm_unfolded = data["iq_norm"].unfold(0, n+1, n)
                ud_unfolded = data["ud"].unfold(0, n+1, n)
                uq_unfolded = data["uq"].unfold(0, n+1, n)
                id_unfolded = data["id"].unfold(0, n+1, n)
                iq_unfolded = data["iq"].unfold(0, n+1, n)
                
                u = torch.column_stack((self.composite_trapezoidal_rule_discrete(ud_unfolded),self.composite_trapezoidal_rule_discrete(uq_unfolded)))
                i = torch.column_stack((self.composite_trapezoidal_rule_discrete(id_unfolded),self.composite_trapezoidal_rule_discrete(iq_unfolded)))
                
                delta_t = data["Time"][n::n] - data["Time"][:-n:n]
                x_train = torch.stack((id_norm_unfolded,iq_norm_unfolded),dim=-1)
                y_train = torch.column_stack([u,i,delta_t,omega_el_unfolded])
        else:
            if self.u_mapping == "next":
                u = torch.column_stack((data["ud"],data["uq"]))[:-1,:]
                omega_el = data["omega_el"][:-1]
            elif self.u_mapping == "previous":
                u = torch.column_stack((data["ud"],data["uq"]))[1:,:]
                omega_el = data["omega_el"][1:]
            else:
                ValueError("u_mapping must be either 'next' or 'previous' or None")
                
            i = torch.column_stack((data["id"][:-1],data["iq"][:-1],data["id"][1:],data["iq"][1:]))
            delta_t = data["Time"][1:] - data["Time"][:-1]
            x_train = torch.column_stack((data["id_norm"][:-1],data["iq_norm"][:-1],data["id_norm"][1:],data["iq_norm"][1:]))
            y_train = torch.column_stack((u,i,omega_el,delta_t))
        
        assembled_data = {"X":x_train,"Y":y_train}
        self._filewriter.write(path,assembled_data)
        
    
class Assembler(OutputComponent):
    def __init__(self,strategy:AssemblingStrategy):
        self._strategy = strategy
        self.metadata = {}
        
    def execute(self,data:pd.DataFrame,path:str,**kwargs):
        if "n" in kwargs.keys():
            self.metadata["n"] = kwargs["n"]
        self._strategy.assemble(path,data,**kwargs)
        
    def get_metadata(self)->Dict:
        return self.metadata
    
    def get_artifacts(self)->Dict:
        return {}

from abc import ABC, abstractmethod
import pandas as pd
from typing import Dict
from typing import Tuple


class FillingStrategy(ABC):
    @abstractmethod
    def fill(self,df:pd.DataFrame)->pd.DataFrame:
        pass
    
    def validate_dataframe(self,df:pd.DataFrame,keys:list[str]):
        new_keys = []
        for key in keys:
            if key in df.columns:
                logging.warning(f"Column '{key}' already exists in the DataFrame and will NOT be overwritten")
            else:
                new_keys.append(key)
        return new_keys
    
class FillTestbench(FillingStrategy):
    def __init__(self):
        self.filling_values = {"r":0.0128, "omega_el":418}
        
    def fill(self,df:pd.DataFrame)->pd.DataFrame:
        keys = self.validate_dataframe(df,self.filling_values.keys())
        for key in keys:
            df[key] = self.filling_values[key]
            logging.info(f"Filled DataFrame with column '{key}' and value {self.filling_values[key]}")
        return df
    
class FillSim(FillingStrategy):
    def __init__(self):
        self.filling_values = {"r":0.02308, "omega_el":418.879020478639}
        
    def fill(self,df:pd.DataFrame)->pd.DataFrame:
        keys = self.validate_dataframe(df,self.filling_values.keys())
        for key in keys:
            df[key] = self.filling_values[key]
            logging.info(f"Filled DataFrame with column '{key}' and value{self.filling_values[key]}")
        return df
    
        
class FillMissingData(InnerComponent):
    def __init__(self,fill_strategy:FillingStrategy):
        self.fill_strategy = fill_strategy
        
    def execute(self,data:pd.DataFrame)->pd.DataFrame:
        try:
            logging.info("Executing fill strategy")
            return self.fill_strategy.fill(data)
        except Exception as e:
            logging.error(f"Error during filling data: {e}")
            raise
    
    def get_artifacts(self):
        return {}
    
    def get_metadata(self):
        return {}#
import pandas as pd
import numpy as np
import logging

class CurrentLimitFilter(InnerComponent):
    def __init__(self):
        self.max_current = np.inf
    
    def execute(self,df:pd.DataFrame,compute_max_current = False, max_current=None)->pd.DataFrame:
        if not {'id', 'iq'}.issubset(df.columns):
            logging.error("DataFrame must contain 'id' and 'iq' columns")
            raise ValueError("DataFrame must contain 'id' and 'iq' columns")
        
        logging.info("Filtering DataFrame based on current limit")
        
        if compute_max_current:
             self.max_current = np.max(np.sqrt(df["id"].values**2+df["iq"].values**2))
        else:
            if max_current is not None:
                self.max_current = max_current
             
        i = df[["id","iq"]].values
        condition = i[:,0]**2+i[:,1]**2 < self.max_current**2
        filtered_indices = np.where(condition)[0]
        val_filtered = df.iloc[filtered_indices]
        
        logging.info("Filtering completed successfully")
        return val_filtered
    
    def get_artifacts(self):
        return {}
    
    def get_metadata(self):
        return {"max_current":self.max_current}
    
from sklearn.preprocessing import StandardScaler
import pandas as pd
import logging
from typing import Dict

class Normalizer(InnerComponent):
    def __init__(self,keys:list[str]):
        self.scaler = StandardScaler()
        self.keys = keys
        self.transformed_keys = [f"{key}_norm" for key in keys]
        
    def execute(self,df:pd.DataFrame,fit:bool=False)->pd.DataFrame:
        if not set(self.keys).issubset(df.columns):
            logging.error(f"DataFrame must contain columns: {self.keys}")
            raise ValueError(f"DataFrame must contain columns: {self.keys}")
        
        logging.info("Normalizing DataFrame columns")
        
        # Perform normalization
        if fit is True:
            df[self.transformed_keys] = self.scaler.fit_transform(df[self.keys])
            logging.info("Fitted and transformed the DataFrame columns")
        else:
            df[self.transformed_keys] = self.scaler.transform(df[self.keys])
            logging.info("Transformed the DataFrame columns using existing scaler")
    
        return df
        
    def get_artifacts(self)->Dict:
        """
        Returns the scaler used for normalization.

        Returns:
        StandardScaler: The scaler used for normalization.
        """
        return {"scaler":self.scaler}
    
    def get_metadata(self):
        return {}
    
from abc import ABC, abstractmethod
import logging
import pandas as pd
import os
from typing import Dict


class LoadingStrategy(ABC):
    def __init__(self,fileloader:FileLoader):
        self._fileloader = fileloader
        
    @abstractmethod
    def load(self,path:str)-> Dict[str, pd.DataFrame]:
        pass
   
class LoadSimFiles(LoadingStrategy):
    def load(self,path:str)-> Dict[str, pd.DataFrame]:
        dir,file = os.path.split(path)
        logging.info(f"Loading data from {path}.csv")
        data = self._fileloader.execute(f"{path}.csv", as_dataframe=True)
        
        logging.info(f"Loading validation data from {os.path.join(dir,'validationdata.csv')}")
        val = self._fileloader.execute(os.path.join(dir,"validationdata.csv"), as_dataframe=True)
        
        logging.info(f"Loading metadata from {path}_metadata.csv")
        meta = self._fileloader.execute(f"{path}_metadata.csv", as_dataframe=True)
        
        logging.info("Data loading completed successfully")
        return {"data": data, "validation": val, "metadata": meta}
    
class LoadTestbenchFile(LoadingStrategy):
    def load(self,path:str)-> Dict[str, pd.DataFrame]:
        logging.info(f"Loading data from {path}.csv")
        data = self._fileloader.execute(f"./data/prüfstand/cut/{path}.csv",as_dataframe=True)
        
        logging.info("Loading validation data")
        val = self._fileloader.execute("./data/prüfstand/LUT/lwr_tables.csv",as_dataframe=True)
        
        logging.info("Data loading completed successfully")
        return {"data": data, "validation": val}
         
class DataLoader(InputComponent):
    def __init__(self,strategy:LoadingStrategy):
        self._strategy = strategy
        
    def execute(self,path:str)->Dict[str, pd.DataFrame]:
        try:
            logging.info(f"Using strategy {self._strategy.__class__.__name__} to load data")
            return self._strategy.load(path)
        except Exception as e:
            logging.error(f"Failed to load data using strategy {self._strategy.__class__.__name__}: {e}")
            raise
    def get_artifacts(self):
        return {}
    def get_metadata(self):
        return {}
        
# Example usage:
#fileloader = FileLoader()
#strategy = LoadSimFiles(fileloader)
#data_loader = DataLoader(strategy)
#data_loader.execute("path/to/file")

import pandas as pd
import json
import os
from scipy.io import loadmat
from typing import Dict


from typing import List, Dict, Any
import pandas as pd
import os
import logging

class Pipeline:
    def __init__(self,components:List[Component],filewriter:FileWriter):
        self.components = components
        self.file_writer = filewriter
    
    def run(self, df: pd.DataFrame, component_args: Dict[str, Dict[str, Any]]):
        # Process the DataFrame through the pipeline
        for component in self.components:
            component_name = component.__class__.__name__
            args = component_args.get(component_name, {})
            
            df = component.execute(df, **args)
        
    def get_artifacts(self)->Dict:
        artifacts ={}
        for component in self.components:
            for key,value in component.get_artifacts().items():
                if key in artifacts.keys():
                    logging.info(f"metadata Key '{key}' is being overridden.")
                artifacts[key] = value
        return artifacts
    
    def get_metadata(self)->pd.DataFrame:
        metadata = {}
        for component in self.components:
            for key, value in component.get_metadata().items():
                if key in metadata.keys():
                    logging.info(f"metadata Key '{key}' is being overridden.")
                metadata[key] = value
        metadata = pd.DataFrame(metadata,index=[0])
        return metadata

import pandas as pd
import os
from typing import Dict,List,Any
import logging


class PipelineExecutor:
    def __init__(self,pipelines:Dict[str,Pipeline],filewriter:FileWriter,dataloader:DataLoader,pipeline_data_mapping: Dict[str, str]):
        self.pipelines = pipelines
        self.filewriter = filewriter
        self.dataloader = dataloader
        self.pipeline_data_mapping = pipeline_data_mapping
        
    def run(self,source:str,destination:str,component_args:Dict[str,Dict[str,Dict[str,Any]]]):
        """
        Run all pipelines in the predefined order with the given arguments.
        """
        self.data = self.dataloader.execute(source)
        
        for name, pipeline in self.pipelines.items():
            logging.info(f"running pipeline: '{name}'")
            data_key = self.pipeline_data_mapping.get(name)
            if data_key is None or data_key not in self.data.keys():
                raise ValueError(f"No valid data key found for pipeline '{name}'")
            pipeline.run(self.data[data_key],component_args[name])
            
        self.save_artifacts(destination)
        self.save_metadata(destination)
            
    def save_metadata(self,destination:str)->None:
        metadata =  [p.get_metadata() for p in self.pipelines.values()]
        if "metadata" in self.data.keys():
            metadata.append(self.data["metadata"])
        metadata = pd.concat(metadata,axis=1)
        self.filewriter.write(os.path.join(destination,"metadata.csv"),metadata)
        
    def save_artifacts(self,destination:str)->None:
        for pipeline in self.pipelines.values():
            for key,artifact in pipeline.get_artifacts().items():
                self.filewriter.write(os.path.join(destination,key+".pkl"),artifact)