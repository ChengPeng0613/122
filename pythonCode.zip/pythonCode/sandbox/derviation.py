import torch
from sklearn.preprocessing import StandardScaler


def calc_derivative(outputs: torch.Tensor, inputs: torch.Tensor, preprocessing_scaler: StandardScaler = None) -> list:
    """
    Calculate the partial derivatives of the outputs with respect to the inputs.

    Args:
        outputs (torch.Tensor): batch of The output tensor.
        inputs (torch.Tensor): batch of The input tensor.
        preprocessing_scaler (sklearn.preprocessing.StandardScaler): A preprocessing scaler function (s).

    Returns:
        torch.Tensor: A Tensor with shape (batchsize,output_dim,input_dim), e.g. a tensor of the jacobian matricies for each input sample
    """
    partial_derivatives = []
    for i in range(outputs.shape[1]):
        grad_outputs = torch.zeros_like(outputs)
        grad_outputs[:, i] = 1
        grads = torch.autograd.grad(outputs, inputs, grad_outputs=grad_outputs, create_graph=True)[0]
        if preprocessing_scaler is not None:
            sigma = torch.from_numpy(preprocessing_scaler.scale_)
            grads = torch.div(grads, sigma)
        partial_derivatives.append(grads)
    partial_derivatives = torch.stack(partial_derivatives,dim=1)
    return partial_derivatives

#Example usage
import torch
import torch.nn as nn

# Define a simple neural network
class SimpleNN(nn.Module):
    def __init__(self):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(2, 3)
    
    def forward(self, x):
        return self.fc1(x)

# Initialize the neural network
model = SimpleNN()

# Define the input tensor
inputs = torch.tensor([[1.0, 2.0], [2,3]], requires_grad=True)

# Forward pass to get the outputs
outputs = model(inputs)
print(outputs.shape)

# Calculate the partial derivatives
partial_derivatives = calc_derivative(outputs, inputs)
print(partial_derivatives.shape)
# Print the partial derivatives
for i, derivative in enumerate(partial_derivatives):
    print(f"Partial derivative with respect to input sample {i}:")
    print(derivative)