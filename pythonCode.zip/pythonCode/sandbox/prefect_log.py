import matplotlib.pyplot as plt

import io

import base64

from prefect import task, flow, get_run_logger

from prefect.artifacts import create_markdown_artifact



@task

def create_plot():

    # Beispiel-Daten

    x = [1, 2, 3, 4, 5]

    y = [10, 20, 25, 30, 40]



    # Plot erstellen

    plt.figure()

    plt.plot(x, y)

    plt.title("Beispiel-Plot")



    # Plot als Bild speichern

    buf = io.BytesIO()

    plt.savefig(buf, format='png')

    buf.seek(0)

    img_base64 = base64.b64encode(buf.read()).decode('utf-8')

    buf.close()



    # Bild als Base64-String zurückgeben

    return img_base64



@task

async def log_plot_as_artifact(img_base64):

    # Bild als Artefakt protokollieren

    markdown_content = f"![Plot](data:image/png;base64,{img_base64})"

    await create_markdown_artifact(

        key="plot-artifact",

        markdown=markdown_content,

        description="Ein Beispiel-Plot als Artefakt"

    )



@flow

def visualization_flow():

    img_base64 = create_plot()

    log_plot_as_artifact(img_base64)


from prefect import flow, task
from prefect.artifacts import (
    create_image_artifact,
)


@task
def create_image():
    # Do something to create an image and upload to a url
    image_url = "https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExZmQydzBjOHQ2M3BhdWJ4M3V1MGtoZGxuNmloeGh6b2dvaHhpaHg0eSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3KC2jD2QcBOSc/giphy.gif"
    create_image_artifact(image_url=image_url, description="A gif.", key="gif")
    create_image_artifact()
    return image_url


@flow
def my_flow():
    return create_image()


if __name__ == "__main__":
    image_url = my_flow()
    print(f"Image URL: {image_url}")