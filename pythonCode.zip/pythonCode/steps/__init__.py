"""In the steps module a various se of idfferent functions used for training end evaluation of the neuronal network"""
import os
import sys

# Dynamically set the PYTHONPATH to include the project directory
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)