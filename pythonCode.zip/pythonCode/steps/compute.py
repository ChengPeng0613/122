import torch


def compute_differential_inductances_fast(outputs: torch.Tensor, inputs: torch.Tensor, 
                                          preprocessing_scaler: callable) -> torch.Tensor:
    """
    Compute differential inductances quickly by calculating the derivative of outputs with respect to inputs.

    Args:
        outputs (torch.Tensor): The output tensor.
        inputs (torch.Tensor): The input tensor.
        preprocessing_scaler (callable): A preprocessing scaler function.

    Returns:
        torch.Tensor: The computed differential inductances.
    """
    deriv = calc_derivative(outputs, inputs, preprocessing_scaler)
    deriv = torch.column_stack(deriv)
    deriv = deriv.detach()
    return deriv

def calc_derivative(outputs: torch.Tensor, inputs: torch.Tensor, preprocessing_scaler: callable) -> list:
    """
    Calculate the partial derivatives of the outputs with respect to the inputs.

    Args:
        outputs (torch.Tensor): The output tensor.
        inputs (torch.Tensor): The input tensor.
        preprocessing_scaler (callable): A preprocessing scaler function.

    Returns:
        list: A list of tensors containing the partial derivatives.
    """
    partial_derivatives = []
    for i in range(outputs.shape[1]):
        grad_outputs = torch.zeros_like(outputs)
        grad_outputs[:, i] = 1
        grads = torch.autograd.grad(outputs, inputs, grad_outputs=grad_outputs, create_graph=True)[0]
        sigma = torch.from_numpy(preprocessing_scaler.scale_)
        grads = torch.div(grads, sigma)
        partial_derivatives.append(grads)
    return partial_derivatives

def compute_state_space_params(inputs: torch.Tensor, psi: torch.Tensor, r: torch.Tensor, 
                               preprocessing_scaler: callable, omega: torch.Tensor) -> dict:
    """
    Compute state-space parameters from inputs, flux linkages, resistance, and angular velocity.

    Args:
        inputs (torch.Tensor): The input tensor.
        psi (torch.Tensor): The flux linkage tensor.
        r (torch.Tensor): The resistance tensor.
        preprocessing_scaler (callable): A preprocessing scaler function.
        omega (torch.Tensor): The angular velocity tensor.

    Returns:
        dict: State-space parameters.
    """
    l_est = compute_differential_inductances_fast(inputs, psi, preprocessing_scaler)
    return physical_parameters_to_state_space(psi, l_est, r, omega)

def physical_parameters_to_state_space(psi: torch.Tensor, l: torch.Tensor, r: torch.Tensor, 
                                       omega: torch.Tensor) -> tuple:
    """
    Convert physical parameters to state-space parameters.

    Args:
        psi (torch.Tensor): The flux linkage tensor.
        l (torch.Tensor): The inductance tensor.
        r (torch.Tensor): The resistance tensor.
        omega (torch.Tensor): The angular velocity tensor.

    Returns:
        tuple: State-space parameters (a_vec, b_vec, e_vec).
    """
    detL = l[:, 0] * l[:, 3] - l[:, 1] * l[:, 2]
    b_vec = torch.column_stack([l[:, 3] / detL, -l[:, 1] / detL, -l[:, 2] / detL, l[:, 0] / detL])
    a_vec = -r * b_vec
    e1 = b_vec[:, 0] * psi[:, 1] - b_vec[:, 1] * psi[:, 0]
    e2 = -b_vec[:, 2] * psi[:, 1] + b_vec[:, 3] * psi[:, 0]
    e_vec = torch.column_stack([e1, -e2]) * omega
    return a_vec, b_vec, e_vec
    

