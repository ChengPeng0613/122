import torch
import numpy as np
from pythonCode.steps.plot import log_3d_plot, log_visualization, log_3d_subplots

def log_psi_3d(pred: torch.Tensor, validation_data: dict) -> None:
    """
    Logs 3D plots for Psi values.

    Args:
        pred (torch.Tensor): Predicted Psi values.
        validation_data (dict): Dictionary containing validation data.

    Returns:
        None
    """
    log_3d_plot(validation_data["i"][:, 0], validation_data["i"][:, 1], [pred[:, 0], validation_data["psi"][:, 0]],
                ["psid estimated", "psid true"], ["id [A]", "iq [A]", "PSI [Wb]"], "Psi d", "psid.html")
    log_3d_plot(validation_data["i"][:, 0], validation_data["i"][:, 1], [pred[:, 1], validation_data["psi"][:, 1]],
                ["psiq estimated", "psiq true"], ["id [A]", "iq [A]", "PSI [Wb]"], "Psi q", "psiq.html")

def log_psi_3d_subplot(pred: torch.Tensor, validation_data: dict) -> None:
    """
    Logs 3D subplots for Psi values.

    Args:
        pred (torch.Tensor): Predicted Psi values.
        validation_data (dict): Dictionary containing validation data.

    Returns:
        None
    """
    axislabels = np.array([[["id [A]", "iq [A]", "PSI [Wb]"], ["id [A]", "iq [A]", "PSI [Wb]"]]])
    plotnames = np.array([[["psid estimated", "psid true"], ["psiq estimated", "psiq true"]]])
    id = torch.tile(validation_data["i"][:, 0], (1, 2, 1))
    iq = torch.tile(validation_data["i"][:, 1], (1, 2, 1))
    pred = torch.stack([torch.stack([pred[:, 0], pred[:, 1]])])
    true = torch.stack([torch.stack([validation_data["psi"][:, 0], validation_data["psi"][:, 1]])])
    z = torch.stack((pred, true), dim=2)
    log_3d_subplots(id, iq, z, plotnames, axislabels, "Magnetische Flüsse", "Psi.html")

def log_l_3d(pred: torch.Tensor, validation_data: dict) -> None:
    """
    Logs 3D plots for inductance values.

    Args:
        pred (torch.Tensor): Predicted inductance values.
        validation_data (dict): Dictionary containing validation data.

    Returns:
        None
    """
    log_3d_plot(validation_data["i"][:, 0], validation_data["i"][:, 1], [pred[:, 0], validation_data["l"][:, 0]],
                ["ldd estimated", "ldd true"], ["id [A]", "iq [A]", "L [Wb/A]"], "ldd", "ldd.html")
    log_3d_plot(validation_data["i"][:, 0], validation_data["i"][:, 1], [pred[:, 1], validation_data["l"][:, 1]],
                ["ldq estimated", "ldq true"], ["id [A]", "iq [A]", "L [Wb/A]"], "ldq", "ldq.html")
    log_3d_plot(validation_data["i"][:, 0], validation_data["i"][:, 1], [pred[:, 2], validation_data["l"][:, 2]],
                ["lqd estimated", "lqd true"], ["id [A]", "iq [A]", "L [Wb/A]"], "lqd", "lqd.html")
    log_3d_plot(validation_data["i"][:, 0], validation_data["i"][:, 1], [pred[:, 3], validation_data["l"][:, 3]],
                ["lqq estimated", "lqq true"], ["id [A]", "iq [A]", "L [Wb/A]"], "lqq", "lqq.html")

def log_l_3d_subplot(pred: torch.Tensor, validation_data: dict) -> None:
    """
    Logs 3D subplots for inductance values.

    Args:
        pred (torch.Tensor): Predicted inductance values.
        validation_data (dict): Dictionary containing validation data.

    Returns:
        None
    """
    axislabels = np.array([[["id [A]", "iq [A]", "L [Wb/A]"], ["id [A]", "iq [A]", "L [Wb/A]"]],
                           [["id [A]", "iq [A]", "L [Wb/A]"], ["id [A]", "iq [A]", "L [Wb/A]"]]])
    plotnames = np.array([[["ldd estimated", "ldd true"], ["ldq estimated", "ldq true"]],
                          [["lqd estimated", "lqd true"], ["lqq estimated", "lqq true"]]])
    id = torch.tile(validation_data["i"][:, 0], (2, 2, 1))
    iq = torch.tile(validation_data["i"][:, 1], (2, 2, 1))
    pred = torch.stack([torch.stack([pred[:, 0], pred[:, 1]]),
                        torch.stack([pred[:, 2], pred[:, 3]])])
    true = torch.stack([torch.stack([validation_data["l"][:, 0], validation_data["l"][:, 1]]),
                        torch.stack([validation_data["l"][:, 2], validation_data["l"][:, 3]])])
    z = torch.stack((pred, true), dim=2)
    log_3d_subplots(id, iq, z, plotnames, axislabels, "Differentielle Induktivitäten", "L.html")

def log_ss_3d_subplot(pred: torch.Tensor, true: torch.Tensor, validation_data: dict, display: bool = False) -> None:
    """
    Logs 3D subplots for state-space parameters.

    Args:
        pred (torch.Tensor): Predicted state-space parameters.
        true (torch.Tensor): True state-space parameters.
        validation_data (dict): Dictionary containing validation data.
        display (bool, optional): Whether to display the plots. Defaults to False.

    Returns:
        None
    """
    axislabels = np.array([[["id [A]", "iq [A]", "a11"], ["id [A]", "iq [A]", "a12"], ["id [A]", "iq [A]", "b11"], ["id [A]", "iq [A]", "b12"], ["id [A]", "iq [A]", "e1"]],
                           [["id [A]", "iq [A]", "a21"], ["id [A]", "iq [A]", "a22"], ["id [A]", "iq [A]", "b21"], ["id [A]", "iq [A]", "b22"], ["id [A]", "iq [A]", "e2"]]])
    plotnames = np.array([[["a11 estimated", "a11 true"], ["a12 estimated", "a12 true"], ["b11 estimated", "b11 true"], ["b12 estimated", "b12 true"], ["e1 estimated", "e1 true"]],
                          [["a21 estimated", "a21 true"], ["a22 estimated", "a22 true"], ["b21 estimated", "b21 true"], ["b22 estimated", "b22 true"], ["e2 estimated", "e2 true"]]])
    pred = torch.stack([torch.stack([pred[:, 0], pred[:, 1], pred[:, 4], pred[:, 5], pred[:, 8]]),
                        torch.stack([pred[:, 2], pred[:, 3], pred[:, 6], pred[:, 7], pred[:, 9]])])
    true = torch.stack([torch.stack([true[:, 0], true[:, 1], true[:, 4], true[:, 5], true[:, 8]]),
                        torch.stack([true[:, 2], true[:, 3], true[:, 6], true[:, 7], true[:, 9]])])
    z = torch.stack((pred, true), dim=2)
    id = torch.tile(validation_data["i"][:, 0], (2, 5, 1))
    iq = torch.tile(validation_data["i"][:, 1], (2, 5, 1))
    log_3d_subplots(id, iq, z, plotnames, axislabels, "state-space-parameter", "ss.html")

def log_psi_error_plane(pred: torch.Tensor, validation_data: dict, display: bool = False) -> None:
    """
    Logs error plane for Psi values.

    Args:
        pred (torch.Tensor): Predicted Psi values.
        validation_data (dict): Dictionary containing validation data.
        display (bool, optional): Whether to display the plots. Defaults to False.

    Returns:
        None
    """
    error = torch.abs(validation_data["psi"] - pred)
    log_visualization(
        data=error,
        pred=error,
        titles=["error Psid", "error Psiq"],
        color_label='MAE [Wb]',
        plot_filename="Psi_mae.png",
        value_range_indices=[0, 1],
        validation_data=validation_data,
        display=display
    )

def log_l_error_plane(pred: torch.Tensor, validation_data: dict, display: bool = False) -> None:
    """
    Logs error plane for inductance values.

    Args:
        pred (torch.Tensor): Predicted inductance values.
        validation_data (dict): Dictionary containing validation data.
        display (bool, optional): Whether to display the plots. Defaults to False.

    Returns:
        None
    """
    error = torch.abs(validation_data["l"] - pred)
    log_visualization(
        data=error,
        pred=error,
        titles=["error ldd", "error ldq", "error lqd", "error lqq"],
        color_label="MAE [WB/A]",
        plot_filename="MAE_l.png",
        value_range_indices=[0, 1, 2, 3],
        validation_data=validation_data,
        display=display
    )

def log_l_visualization(pred: torch.Tensor, validation_data: dict, display: bool = False) -> None:
    """
    Logs visualization for inductance values.

    Args:
        pred (torch.Tensor): Predicted inductance values.
        validation_data (dict): Dictionary containing validation data.
        display (bool, optional): Whether to display the plots. Defaults to False.

    Returns:
        None
    """
    log_visualization(
        data=validation_data["l"],
        pred=pred,
        titles=[
            "ldq from table", "ldq from table", "lqd from table", "lqq from table",
            "ldd estimated", "ldq estimated", "lqd estimated", "lqq estimated"
        ],
        color_label='l [Wb/A]',
        plot_filename="L.png",
        value_range_indices=[0, 1, 2, 3, 0, 1, 2, 3],
        validation_data=validation_data,
        display=display
    )

def log_state_space_parameters_error_plane(true_parameters: torch.Tensor, estimated_parameters: torch.Tensor, validation_data: dict, display: bool = False) -> None:
    """
    Logs error plane for state-space parameters.

    Args:
        true_parameters (torch.Tensor): True state-space parameters.
        estimated_parameters (torch.Tensor): Estimated state-space parameters.
        validation_data (dict): Dictionary containing validation data.
        display (bool, optional): Whether to display the plots. Defaults to False.

    Returns:
        None
    """
    error = torch.abs(true_parameters - estimated_parameters)
    log_visualization(
        data=error,
        pred=error,
        titles=["a11", "a12", "a21", "a22", "b11", "b12", "b21", "b22", "e1", "e2"],
        color_label="error",
        plot_filename="state_space_error.png",
        value_range_indices=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        validation_data=validation_data,
        display=display
    )

def log_prediction_visualization(pred: torch.Tensor, validation_data: dict, display: bool = False) -> None:
    """
    Logs visualization for Psi predictions.

    Args:
        pred (torch.Tensor): Predicted Psi values.
        validation_data (dict): Dictionary containing validation data.
        display (bool, optional): Whether to display the plots. Defaults to False.

    Returns:
        None
    """
    log_visualization(
        data=validation_data["psi"],
        pred=pred,
        titles=["Psid from flux table", "Psiq from flux table", "Psid estimated", "Psiq estimated"],
        color_label='Psi [Wb]',
        plot_filename="Psi.png",
        value_range_indices=[0, 1, 0, 1],
        validation_data=validation_data,
        display=display
    )