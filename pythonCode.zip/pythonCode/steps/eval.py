from scipy.integrate import solve_ivp
import numpy as np
import mlflow
import torch

def calc_ew(vec: np.ndarray) -> np.ndarray:
    """
    Calculate eigenvalues for each 2x2 matrix in the input vector.

    Args:
        vec (np.ndarray): Input array of shape (n, 4) where each row represents a 2x2 matrix.

    Returns:
        np.ndarray: Array of eigenvalues with shape (n, 2).
    """
    eig_vals = np.zeros((vec.shape[0], 2), dtype=complex)
    for index, row in enumerate(vec):
        mat = row.reshape((2, 2))
        eig_vals[index, :] = np.linalg.eigvals(mat)
    return eig_vals
    
def solve_ode_system(idx: int, data_dict: dict, i_dq: np.ndarray) -> tuple:
    """
    Solve an ODE system using given parameters and initial conditions.

    Args:
        idx (int): Index to access specific data in data_dict.
        data_dict (dict): Dictionary containing 'theta_dq' and 'theta_dq_est' arrays.
        i_dq (np.ndarray): Initial conditions array.

    Returns:
        tuple: Solution times and values for both actual and estimated systems.
    """
    i = idx
    A = np.array([[data_dict['theta_dq'][i, 0], data_dict['theta_dq'][i, 1]], 
                  [data_dict['theta_dq'][i, 5], data_dict['theta_dq'][i, 6]]])
    A_est = np.array([[data_dict['theta_dq_est'][i, 0], data_dict['theta_dq_est'][i, 1]], 
                      [data_dict['theta_dq_est'][i, 5], data_dict['theta_dq_est'][i, 6]]])
    E = np.array([data_dict['theta_dq'][i, 4], data_dict["theta_dq"][i, 9]])
    E_est = np.array([data_dict['theta_dq_est'][i, 4], data_dict["theta_dq_est"][i, 9]])
    x0 = i_dq[i, :]
    tspan = [0, 1]
    sol = solve_ivp(lambda t, x: ode_system(x, A, E), tspan, x0, t_eval=np.linspace(tspan[0], tspan[1], 100))
    sol_est = solve_ivp(lambda t, x: ode_system(x, A_est, E_est), tspan, x0, t_eval=np.linspace(tspan[0], tspan[1], 100))
    return sol.t, sol.y.T, sol_est.t, sol_est.y.T

def ode_system(x: np.ndarray, A: np.ndarray, E: np.ndarray) -> np.ndarray:
    """
    Define the ODE system.

    Args:
        x (np.ndarray): State vector.
        A (np.ndarray): Coefficient matrix.
        E (np.ndarray): Constant vector.

    Returns:
        np.ndarray: Result of the ODE system.
    """
    return A @ x + E
   
def validatemodel(model: torch.nn.Module, validation_data: dict, R: torch.Tensor, 
                  eval_loss_fn: callable, step: int, loss: torch.Tensor) -> torch.Tensor:
    """
    Validate the model using the provided validation data and log metrics.

    Args:
        model (torch.nn.Module): The model to be validated.
        validation_data (dict): Dictionary containing validation data.
        R (torch.Tensor): True resistance value.
        eval_loss_fn (callable): Function to evaluate the loss.
        step (int): Current step or epoch number.
        loss (torch.Tensor): Custom loss value.

    Returns:
        torch.Tensor: Sum of the mean absolute errors for psi_d, psi_q, and resistance.
    """
    model.eval()
    with torch.no_grad():
        psi_pred, r = model(validation_data["i_scaled"])
        psid_mae = eval_loss_fn(psi_pred[:, 0], validation_data["psi"][:, 0])
        psiq_mae = eval_loss_fn(psi_pred[:, 1], validation_data["psi"][:, 1])
        r_loss = eval_loss_fn(r, R)
        mlflow.log_metrics({
            "r_est": r.item(),
            "r_true": R.item(),
            "val_r_mae": r_loss.item(),
            "val_psid_mae": psid_mae.item(),
            "val_psiq_mae": psiq_mae.item(),
            "custom_loss": loss.item()
        }, step=step)
    return psid_mae + psiq_mae + r_loss   
