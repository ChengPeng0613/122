import mlflow

def custom_log(dataset_info: dict, model_parameters: dict, train_path: str, 
               validation_path: str, test_path: str, scaler_path: str) -> None:
    """
    Log dataset information, model parameters, and artifacts to MLflow.

    Args:
        dataset_info (dict): Information about the dataset.
        model_parameters (dict): Parameters of the model.
        train_path (str): Path to the training dataset.
        validation_path (str): Path to the validation dataset.
        test_path (str): Path to the test dataset.
        scaler_path (str): Path to the scaler object.

    Returns:
        None
    """
    mlflow.log_params(dataset_info)
    mlflow.log_params(model_parameters)
    mlflow.log_artifact(train_path, artifact_path="datasets")
    mlflow.log_artifact(test_path, artifact_path="datasets")
    mlflow.log_artifact(validation_path, artifact_path="datasets")
    mlflow.log_artifact(scaler_path, artifact_path="scaler")

def get_or_create_run(experiment_id: str, run_name: str) -> str:
    """
    Check whether a run with the specified run_name already exists in MLflow.
    If it does not exist, create a new run with the given run_name.
    
    Args:
        run_name (str): The name of the run to check or create.
    
    Returns:
        str: The run_id of the existing or newly created run.
    """

    # Search for the run by name
    runs = mlflow.search_runs(experiment_ids=[experiment_id], filter_string=f"tags.mlflow.runName = '{run_name}'")

    if not runs.empty:
        # If the run exists, get the run_id
        run_id = runs.iloc[0].run_id
        print(f"Run '{run_name}' already exists with run_id: {run_id}")
    else:
        # If the run does not exist, create a new run
        with mlflow.start_run(run_name=run_name) as run:
            run_id = run.info.run_id
            print(f"Created new run '{run_name}' with run_id: {run_id}")

    return run_id