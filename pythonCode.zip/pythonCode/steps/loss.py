import torch
from typing import Dict

def custom_loss(psi: torch.Tensor, psi_last: torch.Tensor, R: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """
    Compute a custom loss based on the definition of the loss in the paper. Basically it is the MSE of the predicted voltages.

    Args:
        psi (torch.Tensor): Current flux linkage tensor.
        psi_last (torch.Tensor): Previous flux linkage tensor.
        R (torch.Tensor): Resistance tensor.
        y (torch.Tensor): Additional parameter tensor.

    Returns:
        torch.Tensor: The computed custom loss.
    """
    loss = ((y[:, 4] + y[:, 2]) * R / 2 + (psi[:, 0] - psi_last[:, 0]) / y[:, 7] - (psi[:, 1] + psi_last[:, 1]) * y[:, 6] / 2 - y[:, 0])**2 + \
           ((y[:, 5] + y[:, 3]) * R / 2 + (psi[:, 1] - psi_last[:, 1]) / y[:, 7] + (psi[:, 0] + psi_last[:, 0]) * y[:, 6] / 2 - y[:, 1])**2
            
    return torch.mean(loss)

def custom_loss_general(psi: torch.Tensor, R: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """
    Compute a custom loss based on the definition in the paper. But with a more general disretization (trapezoidal rule).

    Args:
        psi (torch.Tensor): Current flux linkage tensor.
        R (torch.Tensor): Resistance tensor.
        y (torch.Tensor): Additional parameter tensor.

    Returns:
        torch.Tensor: The computed custom loss.
    """
    
    loss = (y[:,2] * R  + (psi[:,-1,0] - psi[:,0,0]) / y[:,4]- average_value_trapezoidal_rule_discrete(psi[:,:, 1]*y[:,5:]) - y[:, 0])**2 + \
           (y[:,3] * R  + (psi[:,-1,1] - psi[:,0,1]) / y[:,4]+ average_value_trapezoidal_rule_discrete(psi[:,:, 0]*y[:,5:]) - y[:, 1])**2
            
    return torch.mean(loss)

def average_value_trapezoidal_rule_discrete(y_values_batch):
    """
    Computes the average value of batches of discrete function values
    using the composite trapezoidal rule.

    :param y_values_batch: A 2D tensor where each row is a batch of discrete function values
    :return: A 1D tensor containing the average value for each batch
    """
    n = y_values_batch.size(1) - 1  # Number of intervals (assumes all batches have the same length)
    
    # Apply the trapezoidal rule to compute the integral for each batch
    integral = (y_values_batch[:, 0] + 2 * torch.sum(y_values_batch[:, 1:-1], dim=1) + y_values_batch[:, -1]) / (2 * n)
    
    return integral

def custom_loss_stationary(psi: torch.Tensor, R: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """
    Compute a custom loss for stationary conditions based on the provided parameters.

    Args:
        psi (torch.Tensor): Flux linkage tensor.
        R (torch.Tensor): Resistance tensor.
        y (torch.Tensor): Additional parameter tensor.

    Returns:
        torch.Tensor: The computed custom loss.
    """
    loss = (-psi[:, 1] * y[:, 4] + R * y[:, 2] - y[:, 0])**2 + (psi[:, 0] * y[:, 4] + R * y[:, 3] - y[:, 1])**2
    return torch.mean(loss)

def custom_loss_with_inductances(psi: torch.Tensor, psi_last: torch.Tensor, l: torch.Tensor, 
                                 l_last: torch.Tensor, R: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """
    Compute a custom loss incorporating inductances based on the provided parameters.

    Args:
        psi (torch.Tensor): Current flux linkage tensor.
        psi_last (torch.Tensor): Previous flux linkage tensor.
        l (torch.Tensor): Current inductance tensor.
        l_last (torch.Tensor): Previous inductance tensor.
        R (torch.Tensor): Resistance tensor.
        y (torch.Tensor): Additional parameter tensor.

    Returns:
        torch.Tensor: The computed custom loss.
    """
    did_dt = (y[:, 4] - y[:, 2]) / y[:, 7]
    diq_dt = (y[:, 5] - y[:, 3]) / y[:, 7]
    inductances = (l + l_last) / 2
    loss = ((y[:, 4] + y[:, 2]) * R / 2 + inductances[:, 0] * did_dt + inductances[:, 1] * diq_dt - (psi[:, 1] + psi_last[:, 1]) * y[:, 6] / 2 - y[:, 0])**2 + \
           ((y[:, 5] + y[:, 3]) * R / 2 + inductances[:, 2] * did_dt + inductances[:, 3] * diq_dt + (psi[:, 0] + psi_last[:, 0]) * y[:, 6] / 2 - y[:, 1])**2
    return torch.mean(loss)