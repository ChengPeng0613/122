from torch import nn
import torch
import random
from typing import List, Tuple, Union

class FluxModel(nn.Module):
    """
    A neural network model for predicting flux values.

    Args:
        neurons_per_layer (List[int]): List of integers specifying the number of neurons in each layer.
        use_batchnorm (bool): Whether to use batch normalization.

    Attributes:
        model (nn.Sequential): The sequential model containing the layers.
        r (nn.Parameter): A learnable parameter.
    """
    def __init__(self, neurons_per_layer: List[int], use_batchnorm: bool) -> None:
        super().__init__()
        
        layers = [nn.Linear(2, neurons_per_layer[0]), nn.Tanh()]
        if use_batchnorm:
            layers.append(nn.BatchNorm1d(neurons_per_layer[0]))
            
        for i in range(1, len(neurons_per_layer)):
            layers.append(nn.Linear(neurons_per_layer[i-1], neurons_per_layer[i]))
            if use_batchnorm:
                layers.append(nn.BatchNorm1d(neurons_per_layer[i]))
            layers.append(nn.Tanh())
            
        layers.append(nn.Linear(neurons_per_layer[-1], 2))
        
        self.model = nn.Sequential(*layers)
        self.r = nn.Parameter(torch.tensor([0], dtype=torch.float, requires_grad=True))
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): normalized currents.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: estimted fluxes and resitance.
        """
        return self.model(x), self.r
    
class FluxTempModel(nn.Module):
    """
    A neural network model for predicting flux values including temeperature dependence of fluxes and resistance.

    Args:
        neurons_per_layer (List[int]): List of integers specifying the number of neurons in each layer.
        use_batchnorm (bool): Whether to use batch normalization.

    Attributes:
        model (nn.Sequential): The sequential model containing the layers.
        temp_gain (nn.Parameter): A learnable resistance temperature gain
        base_resistance (nn.Parameter): A learnable resistance at 0°C 
    """
    def __init__(self, neurons_per_layer: List[int], use_batchnorm: bool) -> None:
        super().__init__()
        
        layers = [nn.Linear(3, neurons_per_layer[0]), nn.Tanh()]
        if use_batchnorm:
            layers.append(nn.BatchNorm1d(neurons_per_layer[0]))
            
        for i in range(1, len(neurons_per_layer)):
            layers.append(nn.Linear(neurons_per_layer[i-1], neurons_per_layer[i]))
            if use_batchnorm:
                layers.append(nn.BatchNorm1d(neurons_per_layer[i]))
            layers.append(nn.Tanh())
            
        layers.append(nn.Linear(neurons_per_layer[-1], 2))
        
        self.model = nn.Sequential(*layers)
        self.temp_gain = nn.Parameter(torch.tensor([0], dtype=torch.float, requires_grad=True))
        self.base_resistance = nn.Parameter(torch.tensor([0], dtype=torch.float, requires_grad=True))
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): normalized currents and Temperatures (Rotor,stator).

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: estimted fluxes and resitance.
        """
        return self.model(x), self.base_resistance + x[:,3]*self.temp_gain
    
class DropOutFluxModel(nn.Module):
    """
    A neural network model for predicting flux values with dropout.

    Args:
        neurons_per_layer (List[int]): List of integers specifying the number of neurons in each layer.
        use_batchnorm (bool): Whether to use batch normalization.
        dropout_prob (float): Dropout probability.

    Attributes:
        model (nn.Sequential): The sequential model containing the layers.
        r (nn.Parameter): A learnable parameter.
    """
    def __init__(self, neurons_per_layer: List[int], use_batchnorm: bool, dropout_prob: float) -> None:
        super().__init__()
        
        layers = [nn.Linear(2, neurons_per_layer[0]), nn.Tanh(), nn.Dropout(p=dropout_prob)]
        if use_batchnorm:
            layers.append(nn.BatchNorm1d(neurons_per_layer[0]))
            
        for i in range(1, len(neurons_per_layer)):
            layers.append(nn.Linear(neurons_per_layer[i-1], neurons_per_layer[i]))
            if use_batchnorm:
                layers.append(nn.BatchNorm1d(neurons_per_layer[i]))
            layers.append(nn.Tanh())
            layers.append(nn.Dropout(p=dropout_prob))
            
        layers.append(nn.Linear(neurons_per_layer[-1], 2))
        
        self.model = nn.Sequential(*layers)
        self.model = self.model.float()
        self.r = nn.Parameter(torch.tensor([0], dtype=torch.float, requires_grad=True))
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass of the model.

        Args:
            x (torch.Tensor): normalilzed currents.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: predicted fluxes and resistance.
        """
        return self.model(x), self.r
    
class MasksembleModel(nn.Module):
    """
    A neural network model using Masksemble for uncertainty quantification.

    Args:
        neurons_per_layer (List[int]): List of integers specifying the number of neurons in each layer.
        M (int): Total number of ones per mask.
        S (int): Scale that controls the amount of overlap given N and M.
        N (int): Number of generated masks.

    Attributes:
        mode (str): Mode of the model ('training', 'eval', 'uq').
        layer (List[nn.Linear]): List of linear layers.
        activation (nn.Tanh): Activation function.
        output_layer (nn.Linear): Output layer.
        masks (List[torch.Tensor]): List of generated masks.
        r (nn.Parameter): A learnable parameter.
    """
    def __init__(self, neurons_per_layer: List[int], M: int, S: int, N: int) -> None:
        super().__init__()
        self.mode = "training"
        for num in neurons_per_layer:
            if num != M * S:
                raise ValueError(f"Masksemble parameter and model parameter do not fit! Number of neurons: {num} != M*S = {M*S}. "
                                 "Number of neurons must be equal to M*S for each layer")
                
        self.layer = [nn.Linear(2, neurons_per_layer[0])]
        self.activation = nn.Tanh()
        for i in range(1, len(neurons_per_layer)):
            self.layer.append(nn.Linear(neurons_per_layer[i-1], neurons_per_layer[i]))
        self.output_layer = nn.Linear(neurons_per_layer[-1], 2)
        
        self.masks = list(self.mask_generator(M, S, N).transpose(0, 1))
                    
        self.r = nn.Parameter(torch.tensor([0], dtype=torch.float, requires_grad=True))
        
    def forward(self, x: torch.Tensor) -> Union[Tuple[List[torch.Tensor], torch.Tensor], Tuple[torch.Tensor, torch.Tensor]]:
        """
        if 'self.mode' is set to "eval" only the predictions. if set to "uq" also outputs the variance of the predictions
        If it is set to training the forward pass with a random selcted mask is returned.

        Args:
            x (torch.Tensor): normalized currents.

        Returns:
            Union[Tuple[List[torch.Tensor], torch.Tensor], Tuple[torch.Tensor, torch.Tensor]]: estimated fluxes and restiance. depending on th set mode also the variance of the predictions.
        """
        if self.mode == "training":
            mask = random.choice(self.masks)
            y = self.forward_with_mask(mask, x)
        else:
            predictions = []
            for mask in self.masks:
                predictions.append(self.forward_with_mask(mask, x))
            y = torch.stack(predictions)
            if self.mode == "eval":
                y = torch.mean(y, dim=0)
            if self.mode == "uq":
                y = [torch.mean(y, dim=0), torch.var(y, dim=0)]
        return y, self.r
        
    def forward_with_mask(self, mask: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass with a specific mask.

        Args:
            mask (torch.Tensor): Mask tensor.
            x (torch.Tensor): Input tensor.

        Returns:
            torch.Tensor: Output tensor.
        """
        batch_size = x.size(0)
        mask = mask.unsqueeze(0).expand(batch_size, -1)  # Expand mask to match batch size
        for layer in self.layer:
            x = layer(x)
            x = self.activation(x)
            x = x * mask
        return self.output_layer(x)
    
    def set_mode(self, mode: str) -> None:
        """
        Set the mode of the model, influencing the behavior of the forward pass.

        Args:
            mode (str): One of 'training', 'eval', 'uq'.

        Raises:
            ValueError: If the mode is not supported.
        """
        if mode in ["training", "eval", "uq"]:
            self.mode = mode
        else:
            raise ValueError(f"Unsupported mode {mode}. Only 'training', 'eval', and 'uq' are available.")
        
    def mask_generator(M: int, S: int, N: int) -> torch.Tensor:
        """
        Generate dropout masks according to the Masksemble schema.
        Schema is slightly modified to ensure that no channel is completely dropped.

        Args:
            M (int): Total number of ones per mask.
            S (int): Scale that controls the amount of overlap given N and M.
            N (int): Number of generated masks.

        Returns:
            torch.Tensor: Generated masks.
        """
        zero_rows = 1
        zero_mask = torch.zeros(size=(int(S * M), N))

        for n in range(N):
            one_mask = torch.randperm(int(S * M))[:M]
            zero_mask[one_mask, n] = 1

        zero_rows = torch.sum(zero_mask.sum(dim=1) == 0)
            
        return zero_mask