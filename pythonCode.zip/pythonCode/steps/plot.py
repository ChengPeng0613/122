import torch
from typing import Tuple
import numpy as np
import plotly.graph_objects as go
import mlflow
import matplotlib.pyplot as plt
from plotly.subplots import make_subplots
from scipy.spatial import Delaunay


def log_3d_plot(id:torch.Tensor, iq:torch.Tensor, zs:list, plotnames:list, axislabels:list, title:str, filename:str) -> None:
    """create a 3d plot with the surfaces in zs and save it as html to mlflow
    Args:
        id (torch.Tensor): _description_
        iq (torch.Tensor): _description_
        zs (list): _description_
        plotnames (list): _description_
        axislabels (list): _description_
        title (str): _description_
        filename (str): _description_
    """
    colors =["yellow","blue"]
    fig = go.Figure()
    points2D = np.vstack([id,iq]).T
    tri = Delaunay(points2D)
    for i,z in enumerate(zs):
        fig.add_trace(
            go.Mesh3d(
                x=id, y=iq, z=z,
                i=tri.simplices[:, 0],
                j=tri.simplices[:, 1],
                k=tri.simplices[:, 2],
                name=plotnames[i],
                colorscale=[[0,colors[i]],[1,colors[i]]],
                showlegend=True,
                showscale=False),
        )
    fig.update_traces(contours_z=dict(show=True, usecolormap=True,
                                  highlightcolor="limegreen", project_z=True,size=0.4,    start=0,  # Starting value of the contours
    end=10))
    fig.update_layout(
        title=title,
        scene=dict(
            xaxis_title=axislabels[0],
            yaxis_title=axislabels[1],
            zaxis_title=axislabels[2]
        )
    )
    
    fig.write_html("temp.html")
    mlflow.log_artifact("temp.html",f"html_plots/{filename}")
 
def log_3d_subplots(id:torch.Tensor, iq:torch.Tensor, zs:torch.Tensor, plotnames:np.ndarray, axislabels:np.ndarray, title:str,filename:str) -> None:
    """creates a grid of subplots with int the layout rows X cols 

    Args:
        id (torch.Tensor): shape should be (rows,cols,num_datapoints)
        iq (torch.Tensor): shape should be (rows,cols,num_datapoints)
        zs (torch.Tensor): shape should be (rows,cols,surfaces)
        plotnames (np.ndarray): shape should be (rows,cols,surfaces)
        axislabels (np.ndarray):shape should be (rows,cols,3)
        title (str): _description_
        filename (str): _description_
    """
    specs = [[{'type': 'surface'} for c in range(zs.size(1))] for r in range(zs.size(0))]
    fig = make_subplots(rows = zs.size(0), cols=zs.size(1),specs=specs)
    colors = ["yellow","blue"]
    for row in range(zs.size(0)):
        for col in range(zs.size(1)):
            for i,z in enumerate(zs[row,col]):
                points2D = np.vstack([id[row,col],iq[row,col]]).T
                tri = Delaunay(points2D)
                fig.add_trace(
                    go.Mesh3d(
                        x=id[row,col], y=iq[row,col], z=z,
                        i=tri.simplices[:, 0],
                        j=tri.simplices[:, 1],
                        k=tri.simplices[:, 2],
                        name=plotnames[row,col,i],
                        colorscale=[[0,colors[i]],[1,colors[i]]],
                        showlegend=True,
                        showscale=False),
                    row = row+1,
                    col = col+1
                )
            fig.update_scenes(
                xaxis_title_text=axislabels[row,col,0], yaxis_title_text=axislabels[row,col,1], zaxis_title_text=axislabels[row,col,2],
                row=row+1, col=col+1
            )
    fig.update_layout(
        title_text=title,
    )
    
    fig.write_html("temp.html")
    mlflow.log_artifact("temp.html",f"html_plots/{filename}")
        
def log_visualization(data: torch.Tensor, pred: torch.Tensor, titles: list, color_label: str, 
                      plot_filename: str, value_range_indices: list, validation_data: dict, 
                      display: bool = False) -> None:
    """
    Log visualization of data and predictions as scatter plots.

    Args:
        data (torch.Tensor): Actual data tensor.
        pred (torch.Tensor): Predicted data tensor.
        titles (list): List of titles for the plots.
        color_label (str): Label for the color bar.
        plot_filename (str): Filename for the saved plot.
        value_range_indices (list): Indices to determine value ranges for color scaling.
        validation_data (dict): Validation data containing 'i' values.
        display (bool, optional): Whether to display the plot. Defaults to False.

    Returns:
        None
    """
    fig, ax = plt.subplots(2, len(titles) // 2, figsize=(8 * len(titles) // 4, 6))
    ax = ax.reshape((len(titles),))
    combined_data = torch.column_stack((data, pred))
    
    # Determine value range
    pred_max = torch.max(pred, axis=0)[0]
    data_max = torch.max(data, axis=0)[0]
    max_values = torch.maximum(pred_max, data_max)
    
    pred_min = torch.min(pred, axis=0)[0]
    data_min = torch.min(data, axis=0)[0]
    min_values = torch.minimum(pred_min, data_min)
    
    # Create scatter plots
    for i in range(len(titles)):
        sc = ax[i].scatter(validation_data["i"][:, 0], validation_data["i"][:, 1], marker=".", 
                           c=combined_data[:, i], cmap='viridis',
                           vmin=min_values[value_range_indices[i]], vmax=max_values[value_range_indices[i]])
        
        # Add a color bar
        cbar = plt.colorbar(sc, ax=ax[i])
        cbar.set_label(color_label)
        
        # Set equal scaling for x and y axes and adjust the plot box
        ax[i].set_aspect('equal', 'box')
        
        # Add labels and title
        ax[i].set_xlabel('id [A]')
        ax[i].set_ylabel('iq [A]')
        ax[i].set_title(titles[i])
    
    # Adjust layout to fit everything nicely
    plt.tight_layout()
    if not display:
        plt.close(fig)
    mlflow.log_figure(fig, plot_filename)
    
def log_state_space_plot(true_ss: np.ndarray, est_ss: np.ndarray, display: bool = False) -> None:
    """
    Log a plot comparing true and estimated state-space parameters.

    Args:
        true_ss (np.ndarray): Array of true state-space parameters.
        est_ss (np.ndarray): Array of estimated state-space parameters.
        display (bool, optional): Whether to display the plot. Defaults to False.

    Returns:
        None
    """
    theta_dq_cont_est = np.column_stack((est_ss[:, :2], est_ss[:, 4:6], est_ss[:, 8], est_ss[:, 2:4], est_ss[:, 6:8], est_ss[:, 9]))
    theta_dq_cont = np.column_stack((true_ss[:, :2], true_ss[:, 4:6], true_ss[:, 8], true_ss[:, 2:4], true_ss[:, 6:8], true_ss[:, 9]))
    titles = ["a11", "a12", "b11", "b12", "e1", "a21", "a22", "b21", "b22", "e2"]
    x_values = [x * 10 for x in range(len(theta_dq_cont_est))]
    
    fig = plt.figure(figsize=(14, 8))
    for i in range(10):
        plt.subplot(2, 5, i + 1)
        plt.title(titles[i])
        plt.plot(x_values, theta_dq_cont_est[:, i], label="est")
        plt.plot(x_values, theta_dq_cont[:, i], label="real")
        plt.xlabel("Samples")
        plt.legend()

    plt.tight_layout()
    plt.savefig("state_space.png")
    if not display:
        plt.close(fig)
    mlflow.log_artifact("state_space.png")
    
def log_ew_plot(true_ew: np.ndarray, est_ew: np.ndarray, display: bool = False) -> None:
    """
    Log a plot of true and estimated eigenvalues (EW).

    Args:
        true_ew (np.ndarray): Array of true eigenvalues.
        est_ew (np.ndarray): Array of estimated eigenvalues.
        display (bool, optional): Whether to display the plot. Defaults to False.

    Returns:
        None
    """
    fig = plt.figure()
    plt.grid(True)
    plt.plot(np.real(est_ew.reshape(-1, 1)), np.imag(est_ew.reshape(-1, 1)), "o", label="estimated EW")
    plt.plot(np.real(true_ew.reshape(-1, 1)), np.imag(true_ew.reshape(-1, 1)), "o", label="true EW")
    plt.xlabel("real")
    plt.ylabel("imag")
    plt.axis("equal")
    
    plt.legend()
    
    plt.savefig("ew.png")
    if not display:
        plt.close(fig)
    mlflow.log_artifact("ew.png")