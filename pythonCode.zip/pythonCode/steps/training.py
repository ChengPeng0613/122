import torch
from typing import Dict

def do_training_step(model: torch.nn.Module, optimizer: torch.optim.Optimizer, x: torch.Tensor, 
                     y: torch.Tensor, loss_fn: callable) -> torch.Tensor:
    """
    Perform a single training step.

    Args:
        model (torch.nn.Module): The model to be trained.
        optimizer (torch.optim.Optimizer): The optimizer for updating model parameters.
        x (torch.Tensor): Input tensor.
        y (torch.Tensor): Target tensor.
        loss_fn (callable): Loss function to compute the loss.

    Returns:
        torch.Tensor: The computed loss for the training step.
    """
    # Ensure x and y are of type Float
    assert x.dtype == torch.float32, f"x is not of type float, but {x.dtype}"
    assert y.dtype == torch.float32, f"y is not of type float, but {y.dtype}"
    model.train()
    psi_pred_last, r = model(x[:, :2])
    psi_pred, _ = model(x[:, 2:])
    loss = loss_fn(psi_pred, psi_pred_last, r, y)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    return loss

def do_training_step_general(model: torch.nn.Module, optimizer: torch.optim.Optimizer, batch: torch.Tensor, 
                     y: torch.Tensor, loss_fn: callable) -> torch.Tensor:
    """
    Perform a single training step assuming the general trapeziodal rule as the discretization method.

    Args:
        model (torch.nn.Module): The model to be trained.
        optimizer (torch.optim.Optimizer): The optimizer for updating model parameters.
        batch (torch.Tensor): Input tensor shape [batchsize,n+1,2] where n+1 is the number of current measuremnts for one estimation period
        y (torch.Tensor): Target tensor.
        loss_fn (callable): Loss function to compute the loss.

    Returns:
        torch.Tensor: The computed loss for the training step.
    """
    model.train()
    # Flatten the batch to process all samples at once
    batch_flat = batch.view(-1, 2)
 
    # Forward pass through the model
    psi_pred_flat, r = model(batch_flat)
  
    # Reshape psi_pred to match the original batch shape
    psi_pred = psi_pred_flat.view(batch.size(0), batch.size(1), -1)
    
    # Compute the loss
    loss = loss_fn(psi_pred, r, y)
    
    # Backward pass and optimization step
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    return loss

def do_training_step_stat(model: torch.nn.Module, optimizer: torch.optim.Optimizer, x: torch.Tensor, 
                     y: torch.Tensor, loss_fn: callable) -> torch.Tensor:
    """
    Perform a single training step for stationary data

    Args:
        model (torch.nn.Module): The model to be trained.
        optimizer (torch.optim.Optimizer): The optimizer for updating model parameters.
        x (torch.Tensor): Input tensor.
        y (torch.Tensor): Target tensor.
        loss_fn (callable): Loss function to compute the loss.

    Returns:
        torch.Tensor: The computed loss for the training step.
    """
    model.train()
    psi_pred, r = model(x)
    loss = loss_fn(psi_pred, r, y)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    return loss
class EarlyStopping:
    """
    Early stopping to terminate training when validation loss stops improving.

    Args:
        patience (int, optional): How many epochs to wait after last time validation loss improved. Defaults to 5.
        min_delta (float, optional): Minimum change in the monitored quantity to qualify as an improvement. Defaults to 0.
    """
    def __init__(self, patience: int = 5, min_delta: float = 0) -> None:
        self.patience = patience
        self.min_delta = min_delta
        self.best_loss: float = None
        self.counter: int = 0
        self.early_stop: bool = False

    def __call__(self, val_loss: float) -> None:
        """
        Check if early stopping condition is met.

        Args:
            val_loss (float): Current validation loss.

        Returns:
            None
        """
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True