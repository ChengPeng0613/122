import torch

def compare_dicts(dict1, dict2, tolerance=1e-3):
    for key in dict1.keys():
        if key not in dict2:
            print(f"Key '{key}' not found in the second dictionary.")
            continue
        
        tensor1 = dict1[key].to(torch.float64)
        tensor2 = dict2[key].to(torch.float64)
        
        if tensor1.shape != tensor2.shape:
            print(f"Tensors under key '{key}' have different shapes.")
            print(f"Tensor 1 shape: {tensor1.shape}")
            print(f"Tensor 2 shape: {tensor2.shape}")
            continue
        
        # Perform element-wise comparison with tolerance
        comparison = torch.abs(tensor1 - tensor2) <= tolerance * torch.abs(tensor1)

        # Find indices where elements are not approximately equal
        not_equal_indices = torch.nonzero(~comparison).squeeze()

        if not_equal_indices.numel() > 0:
            print(f"Tensors under key '{key}' are different.")
            print(f"Tensor 1 shape: {tensor1.shape}")
            print(f"Tensor 2 shape: {tensor2.shape}")
            print(f"tensor1: {tensor1}")
            print(f"tensor2: {tensor2}")
            print("Elements apart by more than the set tolerance at indices:", len(not_equal_indices.tolist()))
            for idx in not_equal_indices:
                idx_tuple = tuple(idx.tolist())
                print(f"tensor1{idx_tuple} = {tensor1[idx_tuple]}, tensor2{idx_tuple} = {tensor2[idx_tuple]}")
                break
        else:
            print(f"Tensors under key '{key}' are approximately identical within the set tolerance.")

    for key in dict2.keys():
        if key not in dict1:
            print(f"Key '{key}' not found in the first dictionary.")

train = torch.load("./data/test_testbench_pipeline/train.pt")
train_ref = torch.load("./data/clean/testbench/Rekorder_2025-02-04_12-09-41/train.pt")
compare_dicts(train,train_ref)
